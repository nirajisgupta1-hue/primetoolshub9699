const DAILY_LIMITS = {
  ai_caption: 800,
  ai_seo: 400,
  ai_faq: 400,
  ai_chat: 800,
  ai_cover_letter: 600,
};

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=UTF-8',
      'cache-control': 'no-store',
      ...extraHeaders,
    },
  });
}

function badRequest(message, details) {
  return json({ error: 'bad_request', message, details: details || null }, 400);
}

function upstreamError(message, details) {
  return json({ error: 'upstream_error', message, details: details || null }, 502);
}

function configError(message) {
  return json({ error: 'config_error', message }, 503);
}

function methodNotAllowed(allowed = 'POST') {
  return new Response(JSON.stringify({ error: 'method_not_allowed', message: `Use ${allowed} for this endpoint.` }), {
    status: 405,
    headers: {
      'content-type': 'application/json; charset=UTF-8',
      'allow': allowed,
      'cache-control': 'no-store',
    },
  });
}

async function parseJsonBody(request) {
  try {
    return await request.json();
  } catch {
    return null;
  }
}

function todayUtc() {
  return new Date().toISOString().slice(0, 10);
}

async function ensureUsageTable(db) {
  await db.prepare('CREATE TABLE IF NOT EXISTS api_usage (tool TEXT NOT NULL, usage_date TEXT NOT NULL, request_count INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (tool, usage_date))').run();
}

function isLocalRequest(request) {
  const host = new URL(request.url).hostname;
  return host === '127.0.0.1' || host === 'localhost' || host === '::1';
}

async function incrementUsage(env, tool, request) {
  const limit = DAILY_LIMITS[tool];
  if (!limit) throw new Error(`Unknown tool quota key: ${tool}`);

  const usageDate = todayUtc();
  const quotaKey = `ai_quota:${tool}:${usageDate}`;

  if (env?.API_LIMITS && typeof env.API_LIMITS.get === 'function' && typeof env.API_LIMITS.put === 'function') {
    const currentRaw = await env.API_LIMITS.get(quotaKey);
    const currentCount = Number.parseInt(currentRaw || '0', 10) || 0;

    if (currentCount >= limit) {
      return { allowed: false, limit, count: currentCount, usageDate, quotaMode: 'kv' };
    }

    const nextCount = currentCount + 1;
    await env.API_LIMITS.put(quotaKey, String(nextCount), { expirationTtl: 60 * 60 * 24 * 3 });
    return { allowed: true, limit, count: nextCount, usageDate, quotaMode: 'kv' };
  }

  const db = env?.DB;
  if (!db) {
    if (isLocalRequest(request)) {
      return { allowed: true, limit, count: 0, usageDate, quotaMode: 'local-bypass' };
    }
    throw new Error('Quota storage is missing. Add API_LIMITS KV or DB to Pages Bindings.');
  }

  await ensureUsageTable(db);

  await db.prepare('INSERT OR IGNORE INTO api_usage (tool, usage_date, request_count) VALUES (?, ?, 0)').bind(tool, usageDate).run();

  const beforeRow = await db.prepare('SELECT request_count FROM api_usage WHERE tool = ? AND usage_date = ? LIMIT 1').bind(tool, usageDate).first();
  const currentCount = Number(beforeRow?.request_count || 0);

  if (currentCount >= limit) {
    return { allowed: false, limit, count: currentCount, usageDate, quotaMode: 'db' };
  }

  await db.prepare('UPDATE api_usage SET request_count = request_count + 1, updated_at = CURRENT_TIMESTAMP WHERE tool = ? AND usage_date = ?').bind(tool, usageDate).run();

  return { allowed: true, limit, count: currentCount + 1, usageDate, quotaMode: 'db' };
}

function quotaExceeded(limit, count) {
  return json({
    error: 'limit_reached',
    message: "Today's free AI limit is over. Please try again tomorrow.",
    limit,
    count,
  }, 429);
}

function trimText(value, max = 1200) {
  return String(value || '').replace(/\s+/g, ' ').trim().slice(0, max);
}

function trimMultiline(value, max = 4000) {
  return String(value || '').replace(/\r/g, '').trim().slice(0, max);
}

function jsonStringFromGeminiResponse(payload) {
  const parts = payload?.candidates?.[0]?.content?.parts || [];
  const text = parts.map((part) => part?.text || '').join('').trim();
  return text || '';
}

async function fetchGeminiJson({ apiKey, prompt, temperature = 0.4, maxOutputTokens = 900, model = 'gemini-2.5-flash' }) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`;
  const body = {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: {
      temperature,
      maxOutputTokens,
      responseMimeType: 'application/json',
    },
  };

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'accept': 'application/json',
    },
    body: JSON.stringify(body),
  });

  const payload = await res.json().catch(() => null);
  if (!res.ok) {
    const detail = payload?.error?.message || payload?.error?.status || `Gemini request failed (${res.status}).`;
    throw new Error(detail);
  }

  const text = jsonStringFromGeminiResponse(payload);
  if (!text) throw new Error('Gemini returned an empty response.');

  const cleaned = text
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/```$/i, '')
    .trim();

  try {
    return JSON.parse(cleaned);
  } catch {
    const firstBrace = cleaned.indexOf('{');
    const lastBrace = cleaned.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      return JSON.parse(cleaned.slice(firstBrace, lastBrace + 1));
    }
    const firstBracket = cleaned.indexOf('[');
    const lastBracket = cleaned.lastIndexOf(']');
    if (firstBracket !== -1 && lastBracket !== -1 && lastBracket > firstBracket) {
      return JSON.parse(cleaned.slice(firstBracket, lastBracket + 1));
    }
    throw new Error('Gemini returned invalid JSON.');
  }
}

async function fetchGroqJson({ apiKey, messages, model = 'llama-3.1-8b-instant', temperature = 0.7, maxCompletionTokens = 900 }) {
  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      temperature,
      max_completion_tokens: maxCompletionTokens,
      response_format: { type: 'json_object' },
    }),
  });

  const payload = await res.json().catch(() => null);
  if (!res.ok) {
    const detail = payload?.error?.message || `Groq request failed (${res.status}).`;
    throw new Error(detail);
  }

  const text = payload?.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error('Groq returned an empty response.');
  return JSON.parse(text);
}

const SEO_SCHEMA = {
  type: 'object',
  properties: {
    seo_title: { type: 'string', description: 'An SEO title under about 60 characters when possible.' },
    meta_description: { type: 'string', description: 'A clickable meta description under about 155 characters when possible.' },
    h1: { type: 'string', description: 'A clear on-page heading.' },
    slug: { type: 'string', description: 'A lowercase URL slug using hyphens only.' },
    intro_paragraph: { type: 'string', description: 'A concise intro paragraph for the page.' },
    schema_description: { type: 'string', description: 'A short schema or OG description sentence.' },
    faq_ideas: {
      type: 'array',
      items: { type: 'string' },
      description: 'Four to six FAQ question ideas only, not full answers.'
    }
  },
  required: ['seo_title', 'meta_description', 'h1', 'slug', 'intro_paragraph', 'schema_description', 'faq_ideas']
};

const FAQ_SCHEMA = {
  type: 'object',
  properties: {
    intro: { type: 'string', description: 'A brief intro sentence for the FAQ section.' },
    faqs: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          question: { type: 'string' },
          answer: { type: 'string' }
        },
        required: ['question', 'answer']
      },
      description: 'A list of FAQ pairs.'
    }
  },
  required: ['intro', 'faqs']
};

async function handleAiCaption(request, env) {
  const apiKey = env.GROQ_API_KEY;
  if (!apiKey) {
    return configError(isLocalRequest(request)
      ? 'GROQ_API_KEY is missing for local development. Create a .dev.vars or .env file in the project root.'
      : 'GROQ_API_KEY is missing in Cloudflare Pages secrets.');
  }

  const body = await parseJsonBody(request);
  if (!body) return badRequest('Please send a valid JSON body.');

  const topic = trimMultiline(body.topic, 1200);
  const platform = trimText(body.platform, 40);
  const tone = trimText(body.tone, 40);
  const language = trimText(body.language, 40);
  const goal = trimText(body.goal, 60);
  const audience = trimText(body.audience, 120);
  const keywords = trimText(body.keywords, 260);
  const cta = trimText(body.cta, 120);
  const emojiLevel = trimText(body.emojiLevel, 40);

  if (!topic || topic.length < 8) {
    return badRequest('Please enter the post idea, product, topic, or brief in a little more detail.');
  }

  let quota;
  try {
    quota = await incrementUsage(env, 'ai_caption', request);
  } catch (error) {
    return configError(error instanceof Error ? error.message : String(error));
  }
  if (!quota.allowed) return quotaExceeded(quota.limit, quota.count);

  const messages = [
    {
      role: 'system',
      content: [
        'You generate social media captions for a public website tool.',
        'Return only one valid JSON object.',
        'Do not wrap the response in markdown or code fences.',
        'Use exactly these keys: primary_caption, short_caption, hook, cta_line, hashtags, posting_note.',
        'hashtags must be an array of 5 to 10 hashtag strings starting with #.',
        'primary_caption should feel polished and natural.',
        'short_caption should be compact.',
        'Keep claims realistic and avoid spammy wording.'
      ].join(' '),
    },
    {
      role: 'user',
      content: [
        `Platform: ${platform || 'General social post'}`,
        `Tone: ${tone || 'Balanced'}`,
        `Language style: ${language || 'English'}`,
        `Goal: ${goal || 'Engagement'}`,
        `Audience: ${audience || 'General audience'}`,
        `Keywords or hooks: ${keywords || 'None provided'}`,
        `CTA preference: ${cta || 'Soft CTA'}`,
        `Emoji level: ${emojiLevel || 'Medium'}`,
        'Create caption ideas from this brief:',
        topic,
      ].join('\n'),
    },
  ];

  try {
    const result = await fetchGroqJson({ apiKey, messages, model: 'llama-3.1-8b-instant', temperature: 0.8, maxCompletionTokens: 700 });
    if (!result || typeof result !== 'object') throw new Error('Caption response was not valid JSON.');

    const normalized = {
      primary_caption: trimMultiline(result.primary_caption, 1800),
      short_caption: trimMultiline(result.short_caption, 800),
      hook: trimText(result.hook, 180),
      cta_line: trimText(result.cta_line, 180),
      hashtags: Array.isArray(result.hashtags)
        ? result.hashtags.map((tag) => String(tag || '').trim()).filter(Boolean).slice(0, 10)
        : [],
      posting_note: trimText(result.posting_note, 220),
    };

    if (!normalized.primary_caption) throw new Error('Caption response did not include the main caption.');

    return json(normalized, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
      'x-pt-quota-mode': quota.quotaMode || 'db',
    });
  } catch (error) {
    return upstreamError('AI caption generation is temporarily unavailable. Please try again shortly.', error instanceof Error ? error.message : String(error));
  }
}

async function fetchSeoWithGroqFallback(apiKey, data) {
  const messages = [
    {
      role: 'system',
      content: [
        'You create clean SEO page copy for a public tools website.',
        'Return only one valid JSON object.',
        'Do not wrap the response in markdown or code fences.',
        'Use exactly these keys: seo_title, meta_description, h1, slug, intro_paragraph, schema_description, faq_ideas.',
        'faq_ideas must be an array of 4 to 6 short question strings.',
        'Avoid keyword stuffing and unrealistic claims.'
      ].join(' '),
    },
    {
      role: 'user',
      content: [
        `Topic or page name: ${data.topic}`,
        `Page type: ${data.pageType || 'Tool page'}`,
        `Brand name: ${data.brand || 'Prime Tools Hub'}`,
        `Target audience: ${data.audience || 'General public'}`,
        `Primary region or audience scope: ${data.region || 'Global'}`,
        `Important keywords: ${data.keywords || 'None provided'}`,
        `Page summary or purpose: ${data.summary || 'None provided'}`,
      ].join('\n'),
    },
  ];

  return fetchGroqJson({ apiKey, messages, model: 'llama-3.1-8b-instant', temperature: 0.4, maxCompletionTokens: 850 });
}

async function fetchFaqWithGroqFallback(apiKey, data) {
  const messages = [
    {
      role: 'system',
      content: [
        'You generate clear FAQ content for a public website page.',
        'Return only one valid JSON object.',
        'Do not wrap the response in markdown or code fences.',
        'Use exactly these keys: intro, faqs.',
        'faqs must be an array of objects with question and answer keys.',
        'Questions should sound search-friendly and natural.',
        'Answers should be concise and practical.'
      ].join(' '),
    },
    {
      role: 'user',
      content: [
        `Topic: ${data.topic}`,
        `Audience: ${data.audience || 'General public'}`,
        `Tone: ${data.tone || 'Clear and friendly'}`,
        `Region or scope: ${data.region || 'Global'}`,
        `Keyword hints: ${data.keywords || 'None provided'}`,
        `Background summary: ${data.summary || 'None provided'}`,
        `Return ${data.faqCount} FAQ pairs.`
      ].join('\n'),
    },
  ];

  return fetchGroqJson({ apiKey, messages, model: 'llama-3.1-8b-instant', temperature: 0.5, maxCompletionTokens: 1100 });
}


function titleCaseWords(value) {
  return String(value || '').split(/\s+/).filter(Boolean).map((word) => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
}

function buildSeoFallback({ topic, pageType, brand, audience, region, keywords, summary }) {
  const rawKeywords = String(keywords || '').split(',').map((item) => item.trim()).filter(Boolean);
  const primaryKeyword = rawKeywords[0] || topic;
  const safeTopic = titleCaseWords(topic || 'Page');
  const safeBrand = brand || 'Prime Tools Hub';
  const safeRegion = region || 'Online';
  const slug = String(primaryKeyword || topic || 'page').toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  const questions = [
    `What is this ${safeTopic.toLowerCase()} tool used for?`,
    `Is this ${safeTopic.toLowerCase()} page free to use?`,
    `Can I use this ${safeTopic.toLowerCase()} page on mobile?`,
    `Do I need to sign up before using this ${safeTopic.toLowerCase()} page?`,
    `Who is this ${safeTopic.toLowerCase()} page best for?`,
  ];
  return {
    seo_title: trimText(`Free ${safeTopic} Online | ${safeBrand}`, 90),
    meta_description: trimText(`Use this ${safeTopic.toLowerCase()} page online to create faster, clearer copy for ${safeRegion} users. Mobile-friendly, browser-based, and easy to review before publishing.`, 220),
    h1: trimText(`${safeTopic} Online`, 120),
    slug,
    intro_paragraph: trimMultiline(summary || `Use this ${safeTopic.toLowerCase()} page to create cleaner website copy for ${audience || 'general users'}. Start with the main topic, review the suggested wording, and then refine the result to match your brand and page intent.`, 900),
    schema_description: trimText(`A browser-based ${safeTopic.toLowerCase()} page on ${safeBrand} for fast, review-friendly output.`, 220),
    faq_ideas: questions.slice(0, 6),
  };
}

function buildFaqFallback({ topic, audience, tone, region, keywords, faqCount }) {
  const safeTopic = titleCaseWords(topic || 'This page');
  const rawKeywords = String(keywords || '').split(',').map((item) => item.trim()).filter(Boolean);
  const bestFor = audience || 'general users';
  const scope = region || 'general use';
  const faqs = [
    {
      question: `What is ${safeTopic.toLowerCase()} used for?`,
      answer: `${safeTopic} helps users create clearer content and faster first drafts for ${scope}. It is useful when you want a starting point that can still be reviewed and edited before final use.`
    },
    {
      question: `Is ${safeTopic.toLowerCase()} free to use?`,
      answer: `The tool is designed for free public use with a shared daily limit. If the limit is available, you can generate output without creating an account and review the result directly on the page.`
    },
    {
      question: `Do I need to sign up before using ${safeTopic.toLowerCase()}?`,
      answer: `No signup is required for the standard workflow. You can open the page, add your prompt or page details, and generate a result directly in the browser.`
    },
    {
      question: `Who is ${safeTopic.toLowerCase()} best for?`,
      answer: `${safeTopic} is best for ${bestFor} who want quicker drafts, clearer wording, and an easier starting point before they publish or share final content.`
    },
    {
      question: `Should I review the generated output before using it?`,
      answer: `Yes. Generated output should always be checked for accuracy, brand tone, names, numbers, and claims. A quick review helps the final content feel more reliable and more aligned with your page goals.`
    },
    {
      question: `Can I use ${safeTopic.toLowerCase()} on mobile?`,
      answer: `Yes. The page is designed to stay usable on mobile so you can generate, review, and copy the content on a phone as well as on a desktop browser.`
    },
  ];
  return {
    intro: trimText(`Use these FAQ ideas as a clean starting point for ${safeTopic.toLowerCase()}. Review each answer and adjust details so the final version matches your page, audience, and brand voice.`, 240),
    faqs: faqs.slice(0, faqCount || 6),
  };
}

async function handleAiSeo(request, env) {
  const apiKey = env.GEMINI_API_KEY;
  if (!apiKey) {
    return configError(isLocalRequest(request)
      ? 'GEMINI_API_KEY is missing for local development. Create a .dev.vars or .env file in the project root.'
      : 'GEMINI_API_KEY is missing in Cloudflare Pages secrets.');
  }

  const body = await parseJsonBody(request);
  if (!body) return badRequest('Please send a valid JSON body.');

  const topic = trimText(body.topic, 180);
  const pageType = trimText(body.pageType, 60);
  const brand = trimText(body.brand, 80);
  const audience = trimText(body.audience, 120);
  const region = trimText(body.region, 80);
  const keywords = trimText(body.keywords, 320);
  const summary = trimMultiline(body.summary, 2200);

  if (!topic || topic.length < 4) {
    return badRequest('Please enter the page topic or tool name.');
  }

  let quota;
  try {
    quota = await incrementUsage(env, 'ai_seo', request);
  } catch (error) {
    return configError(error instanceof Error ? error.message : String(error));
  }
  if (!quota.allowed) return quotaExceeded(quota.limit, quota.count);

  const prompt = [
    'Create clean, natural SEO page copy for a public tools website.',
    'Avoid keyword stuffing, hype, and false claims.',
    'Prefer concise, clickable wording.',
    'Keep the title around 50-60 characters and the meta description around 140-155 characters when possible.',
    `Topic or page name: ${topic}`,
    `Page type: ${pageType || 'Tool page'}`,
    `Brand name: ${brand || 'Prime Tools Hub'}`,
    `Target audience: ${audience || 'General public'}`,
    `Primary region or audience scope: ${region || 'Global'}`,
    `Important keywords: ${keywords || 'None provided'}`,
    `Page summary or purpose: ${summary || 'None provided'}`,
    'Return only valid JSON with exactly these keys: seo_title, meta_description, h1, slug, intro_paragraph, schema_description, faq_ideas. faq_ideas must be an array of short question strings. Do not wrap the output in markdown or code fences.'
  ].join('\n');

  try {
    let result;
    try {
      result = await fetchGeminiJson({ apiKey, prompt, temperature: 0.4, maxOutputTokens: 850, model: 'gemini-2.5-flash' });
    } catch (geminiError) {
      if (!env.GROQ_API_KEY) throw geminiError;
      result = await fetchSeoWithGroqFallback(env.GROQ_API_KEY, { topic, pageType, brand, audience, region, keywords, summary });
    }
    if (!result || typeof result !== 'object') throw new Error('SEO response was not valid JSON.');

    const normalized = {
      seo_title: trimText(result.seo_title, 90),
      meta_description: trimText(result.meta_description, 220),
      h1: trimText(result.h1, 120),
      slug: trimText(result.slug, 120).toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, ''),
      intro_paragraph: trimMultiline(result.intro_paragraph, 900),
      schema_description: trimText(result.schema_description, 220),
      faq_ideas: Array.isArray(result.faq_ideas) ? result.faq_ideas.map((item) => trimText(item, 160)).filter(Boolean).slice(0, 6) : [],
    };

    if (!normalized.seo_title || !normalized.meta_description) throw new Error('SEO response was missing the title or meta description.');

    return json(normalized, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
      'x-pt-quota-mode': quota.quotaMode || 'db',
    });
  } catch (error) {
    const fallback = buildSeoFallback({ topic, pageType, brand, audience, region, keywords, summary });
    return json(fallback, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
      'x-pt-quota-mode': quota.quotaMode || 'db',
      'x-pt-fallback': 'template',
    });
  }
}

async function handleAiFaq(request, env) {
  const apiKey = env.GEMINI_API_KEY;
  if (!apiKey) {
    return configError(isLocalRequest(request)
      ? 'GEMINI_API_KEY is missing for local development. Create a .dev.vars or .env file in the project root.'
      : 'GEMINI_API_KEY is missing in Cloudflare Pages secrets.');
  }

  const body = await parseJsonBody(request);
  if (!body) return badRequest('Please send a valid JSON body.');

  const topic = trimText(body.topic, 180);
  const summary = trimMultiline(body.summary, 2200);
  const audience = trimText(body.audience, 120);
  const tone = trimText(body.tone, 60);
  const region = trimText(body.region, 80);
  const keywords = trimText(body.keywords, 320);
  const faqCount = Math.max(4, Math.min(8, Number(body.faqCount || 6)));

  if (!topic || topic.length < 4) {
    return badRequest('Please enter the topic, page, product, or service for the FAQ section.');
  }

  let quota;
  try {
    quota = await incrementUsage(env, 'ai_faq', request);
  } catch (error) {
    return configError(error instanceof Error ? error.message : String(error));
  }
  if (!quota.allowed) return quotaExceeded(quota.limit, quota.count);

  const prompt = [
    'Generate clear FAQ content for a public website page.',
    'Questions should sound natural, helpful, and search-friendly.',
    'Answers should be concise and practical, usually 35 to 90 words.',
    'Avoid fake guarantees, medical advice, legal claims, or unsupported promises.',
    `Topic: ${topic}`,
    `Audience: ${audience || 'General public'}`,
    `Tone: ${tone || 'Clear and friendly'}`,
    `Region or scope: ${region || 'Global'}`,
    `Keyword hints: ${keywords || 'None provided'}`,
    `Background summary: ${summary || 'None provided'}`,
    `Return only valid JSON with exactly these keys: intro, faqs. faqs must be an array of objects with question and answer keys. Return ${faqCount} FAQ pairs. Do not wrap the output in markdown or code fences.`
  ].join('\n');

  try {
    let result;
    try {
      result = await fetchGeminiJson({ apiKey, prompt, temperature: 0.5, maxOutputTokens: 1100, model: 'gemini-2.5-flash' });
    } catch (geminiError) {
      if (!env.GROQ_API_KEY) throw geminiError;
      result = await fetchFaqWithGroqFallback(env.GROQ_API_KEY, { topic, summary, audience, tone, region, keywords, faqCount });
    }
    if (!result || typeof result !== 'object') throw new Error('FAQ response was not valid JSON.');

    const faqs = Array.isArray(result.faqs)
      ? result.faqs.map((entry) => ({
          question: trimText(entry?.question, 180),
          answer: trimMultiline(entry?.answer, 520),
        })).filter((entry) => entry.question && entry.answer).slice(0, faqCount)
      : [];

    if (!faqs.length) throw new Error('FAQ response did not include any question and answer pairs.');

    const normalized = {
      intro: trimText(result.intro, 240),
      faqs,
    };

    return json(normalized, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
      'x-pt-quota-mode': quota.quotaMode || 'db',
    });
  } catch (error) {
    const fallback = buildFaqFallback({ topic, audience, tone, region, keywords, faqCount });
    return json(fallback, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
      'x-pt-quota-mode': quota.quotaMode || 'db',
      'x-pt-fallback': 'template',
    });
  }
}



function normalizeStringArray(value, maxItems = 6, maxLength = 180) {
  return Array.isArray(value)
    ? value.map((item) => trimText(item, maxLength)).filter(Boolean).slice(0, maxItems)
    : [];
}

function buildChatFallback({ prompt, mode, tone, goal }) {
  const cleanPrompt = trimMultiline(prompt, 1400);
  const shortPrompt = trimText(cleanPrompt, 180);
  return {
    headline: trimText(mode || 'AI Chat Response', 80),
    answer: `Here is a clean starter response based on your request: ${shortPrompt || 'Your request has been received.'} This fallback version is designed to stay useful even if the AI provider is temporarily unavailable.`,
    bullet_points: [
      `Tone requested: ${tone || 'Balanced'}`,
      `Goal focus: ${goal || 'General help'}`,
      'Review the answer and add any missing names, facts, or context.',
      'Ask a more specific follow-up for a sharper result.'
    ],
    next_steps: [
      'Refine the prompt with more detail or examples.',
      'Mention the exact format you want, such as bullets, steps, or a short reply.',
      'Check important facts before using the final answer.'
    ],
    follow_up_prompts: [
      'Make this answer shorter.',
      'Rewrite this in a more professional tone.',
      'Turn this into a step-by-step checklist.'
    ],
    caution: 'This is a fallback response. Review facts, claims, and sensitive advice before using it.'
  };
}

async function handleAiChat(request, env) {
  const groqKey = env.GROQ_API_KEY;
  const geminiKey = env.GEMINI_API_KEY;
  if (!groqKey && !geminiKey) {
    return configError(isLocalRequest(request)
      ? 'GROQ_API_KEY or GEMINI_API_KEY is missing for local development. Create a .dev.vars or .env file in the project root.'
      : 'GROQ_API_KEY or GEMINI_API_KEY is missing in Cloudflare Pages secrets.');
  }

  const body = await parseJsonBody(request);
  if (!body) return badRequest('Please send a valid JSON body.');

  const prompt = trimMultiline(body.prompt, 2600);
  const mode = trimText(body.mode, 80);
  const tone = trimText(body.tone, 80);
  const length = trimText(body.length, 40);
  const language = trimText(body.language, 60);
  const audience = trimText(body.audience, 120);
  const goal = trimText(body.goal, 180);
  const extraContext = trimMultiline(body.context, 2200);

  if (!prompt || prompt.length < 8) {
    return badRequest('Please enter a little more detail for the chat request.');
  }

  let quota;
  try {
    quota = await incrementUsage(env, 'ai_chat', request);
  } catch (error) {
    return configError(error instanceof Error ? error.message : String(error));
  }
  if (!quota.allowed) return quotaExceeded(quota.limit, quota.count);

  try {
    let result = null;

    if (groqKey) {
      const messages = [
        {
          role: 'system',
          content: [
            'You generate structured output for a public browser-based AI chat helper.',
            'Return only one valid JSON object.',
            'Do not wrap the response in markdown or code fences.',
            'Use exactly these keys: headline, answer, bullet_points, next_steps, follow_up_prompts, caution.',
            'bullet_points must be an array of 3 to 6 items.',
            'next_steps must be an array of 2 to 5 items.',
            'follow_up_prompts must be an array of 2 to 4 items.',
            'Keep claims realistic, practical, and safe.',
          ].join(' ')
        },
        {
          role: 'user',
          content: [
            `Mode: ${mode || 'General help'}`,
            `Tone: ${tone || 'Clear and helpful'}`,
            `Length: ${length || 'Medium'}`,
            `Language style: ${language || 'English'}`,
            `Audience: ${audience || 'General audience'}`,
            `Goal: ${goal || 'General help'}`,
            `Context: ${extraContext || 'None provided'}`,
            'User request:',
            prompt,
          ].join('\n')
        }
      ];
      try {
        result = await fetchGroqJson({ apiKey: groqKey, messages, model: 'llama-3.1-8b-instant', temperature: 0.6, maxCompletionTokens: 950 });
      } catch (groqError) {
        if (!geminiKey) throw groqError;
      }
    }

    if (!result && geminiKey) {
      const geminiPrompt = [
        'Generate structured output for a public browser-based AI chat helper.',
        'Return only one valid JSON object with exactly these keys: headline, answer, bullet_points, next_steps, follow_up_prompts, caution.',
        'bullet_points must be an array of 3 to 6 items.',
        'next_steps must be an array of 2 to 5 items.',
        'follow_up_prompts must be an array of 2 to 4 items.',
        'Keep wording practical, clear, and safe. Avoid code fences.',
        `Mode: ${mode || 'General help'}`,
        `Tone: ${tone || 'Clear and helpful'}`,
        `Length: ${length || 'Medium'}`,
        `Language style: ${language || 'English'}`,
        `Audience: ${audience || 'General audience'}`,
        `Goal: ${goal || 'General help'}`,
        `Context: ${extraContext || 'None provided'}`,
        'User request:',
        prompt,
      ].join('\n');
      result = await fetchGeminiJson({ apiKey: geminiKey, prompt: geminiPrompt, temperature: 0.5, maxOutputTokens: 1000, model: 'gemini-2.5-flash' });
    }

    if (!result || typeof result !== 'object') throw new Error('Chat response was not valid JSON.');

    const normalized = {
      headline: trimText(result.headline, 120),
      answer: trimMultiline(result.answer, 2400),
      bullet_points: normalizeStringArray(result.bullet_points, 6, 220),
      next_steps: normalizeStringArray(result.next_steps, 5, 220),
      follow_up_prompts: normalizeStringArray(result.follow_up_prompts, 4, 180),
      caution: trimText(result.caution, 220),
    };

    if (!normalized.answer) throw new Error('Chat response did not include the main answer.');

    return json(normalized, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
      'x-pt-quota-mode': quota.quotaMode || 'db',
    });
  } catch (error) {
    const fallback = buildChatFallback({ prompt, mode, tone, goal });
    return json(fallback, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
      'x-pt-quota-mode': quota.quotaMode || 'db',
      'x-pt-fallback': 'template',
    });
  }
}

function buildCoverLetterFallback({ useCase, roleTitle, company, audience, profile, highlights, ctaGoal }) {
  const target = [roleTitle, company].filter(Boolean).join(' at ') || 'the opportunity';
  const intro = `I am writing regarding ${target}. ${profile ? trimText(profile, 320) : 'I would like to share my interest and relevant background in a clear professional format.'}`;
  const mainBody = `My experience and strengths align with ${audience || 'the intended audience'} and the goals of this message. ${highlights ? `Relevant highlights include: ${trimText(highlights, 260)}.` : 'I bring relevant experience, practical skills, and a strong willingness to contribute.'}`;
  const closing = `${ctaGoal ? trimText(ctaGoal, 180) : 'I would welcome the chance to discuss this further.'} Thank you for your time and consideration.`;
  return {
    subject_line: trimText(useCase || 'Professional Draft', 80),
    opening: trimMultiline(intro, 600),
    main_body: trimMultiline(mainBody, 900),
    closing: trimMultiline(closing, 400),
    short_version: trimText(`Thank you for considering my profile for ${target}. I would be glad to share more details if helpful.`, 260),
    key_highlights: normalizeStringArray((highlights || '').split(/[,;\n]+/).map((item) => item.trim()).filter(Boolean), 5, 120),
    editing_note: 'Review names, role details, dates, claims, links, and tone before sending the final draft.'
  };
}

async function handleAiCoverLetter(request, env) {
  const groqKey = env.GROQ_API_KEY;
  const geminiKey = env.GEMINI_API_KEY;
  if (!groqKey && !geminiKey) {
    return configError(isLocalRequest(request)
      ? 'GROQ_API_KEY or GEMINI_API_KEY is missing for local development. Create a .dev.vars or .env file in the project root.'
      : 'GROQ_API_KEY or GEMINI_API_KEY is missing in Cloudflare Pages secrets.');
  }

  const body = await parseJsonBody(request);
  if (!body) return badRequest('Please send a valid JSON body.');

  const useCase = trimText(body.useCase, 80);
  const tone = trimText(body.tone, 80);
  const length = trimText(body.length, 40);
  const ctaGoal = trimText(body.ctaGoal, 180);
  const roleTitle = trimText(body.roleTitle, 120);
  const company = trimText(body.company, 120);
  const audience = trimText(body.audience, 100);
  const location = trimText(body.location, 120);
  const profile = trimMultiline(body.profile, 2200);
  const highlights = trimText(body.highlights, 320);
  const skills = trimText(body.skills, 320);
  const contextText = trimMultiline(body.context, 2400);

  if ((!roleTitle || roleTitle.length < 2) && (!contextText || contextText.length < 12)) {
    return badRequest('Please add the role title or a little more message context first.');
  }
  if (!profile || profile.length < 8) {
    return badRequest('Please add a short profile or experience summary first.');
  }

  let quota;
  try {
    quota = await incrementUsage(env, 'ai_cover_letter', request);
  } catch (error) {
    return configError(error instanceof Error ? error.message : String(error));
  }
  if (!quota.allowed) return quotaExceeded(quota.limit, quota.count);

  try {
    let result = null;

    if (groqKey) {
      const messages = [
        {
          role: 'system',
          content: [
            'You generate structured professional draft output for a public browser-based writing helper.',
            'Return only one valid JSON object.',
            'Do not wrap the response in markdown or code fences.',
            'Use exactly these keys: subject_line, opening, main_body, closing, short_version, key_highlights, editing_note.',
            'key_highlights must be an array of 3 to 5 short items.',
            'Keep the language polished, natural, and realistic.'
          ].join(' ')
        },
        {
          role: 'user',
          content: [
            `Use case: ${useCase || 'Cover Letter'}`,
            `Tone: ${tone || 'Professional'}`,
            `Length: ${length || 'Medium'}`,
            `CTA goal: ${ctaGoal || 'Invite a reply or next step'}`,
            `Role title: ${roleTitle || 'Not provided'}`,
            `Company or recipient: ${company || 'Not provided'}`,
            `Audience: ${audience || 'Hiring team'}`,
            `Location: ${location || 'Not provided'}`,
            `Profile summary: ${profile}`,
            `Highlights: ${highlights || 'None provided'}`,
            `Skills: ${skills || 'None provided'}`,
            `Extra context: ${contextText || 'None provided'}`,
          ].join('\n')
        }
      ];
      try {
        result = await fetchGroqJson({ apiKey: groqKey, messages, model: 'llama-3.1-8b-instant', temperature: 0.6, maxCompletionTokens: 1100 });
      } catch (groqError) {
        if (!geminiKey) throw groqError;
      }
    }

    if (!result && geminiKey) {
      const prompt = [
        'Generate structured professional writing output for a public browser-based helper.',
        'Return only one valid JSON object with exactly these keys: subject_line, opening, main_body, closing, short_version, key_highlights, editing_note.',
        'key_highlights must be an array of 3 to 5 short items.',
        'Avoid markdown and code fences.',
        `Use case: ${useCase || 'Cover Letter'}`,
        `Tone: ${tone || 'Professional'}`,
        `Length: ${length || 'Medium'}`,
        `CTA goal: ${ctaGoal || 'Invite a reply or next step'}`,
        `Role title: ${roleTitle || 'Not provided'}`,
        `Company or recipient: ${company || 'Not provided'}`,
        `Audience: ${audience || 'Hiring team'}`,
        `Location: ${location || 'Not provided'}`,
        `Profile summary: ${profile}`,
        `Highlights: ${highlights || 'None provided'}`,
        `Skills: ${skills || 'None provided'}`,
        `Extra context: ${contextText || 'None provided'}`,
      ].join('\n');
      result = await fetchGeminiJson({ apiKey: geminiKey, prompt, temperature: 0.45, maxOutputTokens: 1200, model: 'gemini-2.5-flash' });
    }

    if (!result || typeof result !== 'object') throw new Error('Cover letter response was not valid JSON.');

    const normalized = {
      subject_line: trimText(result.subject_line, 120),
      opening: trimMultiline(result.opening, 900),
      main_body: trimMultiline(result.main_body, 1600),
      closing: trimMultiline(result.closing, 700),
      short_version: trimMultiline(result.short_version, 700),
      key_highlights: normalizeStringArray(result.key_highlights, 5, 180),
      editing_note: trimText(result.editing_note, 260),
    };

    if (!normalized.main_body) throw new Error('Cover letter response did not include the main body.');

    return json(normalized, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
      'x-pt-quota-mode': quota.quotaMode || 'db',
    });
  } catch (error) {
    const fallback = buildCoverLetterFallback({ useCase, roleTitle, company, audience, profile, highlights, ctaGoal });
    return json(fallback, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
      'x-pt-quota-mode': quota.quotaMode || 'db',
      'x-pt-fallback': 'template',
    });
  }
}

export default {
  async fetch(request, env) {
    try {
      const url = new URL(request.url);

      if (request.method === 'OPTIONS' && url.pathname.startsWith('/api/')) {
        return new Response(null, {
          status: 204,
          headers: {
            'access-control-allow-origin': '*',
            'access-control-allow-methods': 'POST, OPTIONS',
            'access-control-allow-headers': 'content-type',
            'cache-control': 'no-store',
          },
        });
      }

      if (url.pathname === '/api/ai-caption') {
        if (request.method !== 'POST') return methodNotAllowed('POST');
        return handleAiCaption(request, env);
      }

      if (url.pathname === '/api/ai-seo-meta') {
        if (request.method !== 'POST') return methodNotAllowed('POST');
        return handleAiSeo(request, env);
      }

      if (url.pathname === '/api/ai-faq') {
        if (request.method !== 'POST') return methodNotAllowed('POST');
        return handleAiFaq(request, env);
      }

      if (url.pathname === '/api/ai-chat') {
        if (request.method !== 'POST') return methodNotAllowed('POST');
        return handleAiChat(request, env);
      }

      if (url.pathname === '/api/ai-cover-letter') {
        if (request.method !== 'POST') return methodNotAllowed('POST');
        return handleAiCoverLetter(request, env);
      }

      return env.ASSETS.fetch(request);
    } catch (error) {
      return json({
        error: 'worker_error',
        message: error instanceof Error ? error.message : String(error),
      }, 502);
    }
  },
};
