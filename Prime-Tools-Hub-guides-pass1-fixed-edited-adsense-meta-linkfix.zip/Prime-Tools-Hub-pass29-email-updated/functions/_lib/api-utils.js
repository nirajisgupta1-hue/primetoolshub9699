const DAILY_LIMITS = {
  ai_caption: 800,
  ai_seo: 400,
  ai_faq: 400,
  ai_chat: 500,
  ai_cover_letter: 350,
};

export function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=UTF-8',
      'cache-control': 'no-store',
      ...extraHeaders,
    },
  });
}

export function badRequest(message, details) {
  return json({ error: 'bad_request', message, details: details || null }, 400);
}

export function upstreamError(message, details) {
  return json({ error: 'upstream_error', message, details: details || null }, 502);
}

export function configError(message) {
  return json({ error: 'config_error', message }, 503);
}

export async function parseJsonBody(request) {
  try {
    return await request.json();
  } catch {
    return null;
  }
}

function todayUtc() {
  return new Date().toISOString().slice(0, 10);
}

export async function ensureUsageTable(db) {
  await db.exec(`
    CREATE TABLE IF NOT EXISTS api_usage (
      tool TEXT NOT NULL,
      usage_date TEXT NOT NULL,
      count INTEGER NOT NULL DEFAULT 0,
      updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (tool, usage_date)
    );
  `);
}

export async function incrementUsage(db, tool) {
  if (!db) throw new Error('Database binding is missing. Add DB to Pages Bindings.');
  const limit = DAILY_LIMITS[tool];
  if (!limit) throw new Error(`Unknown tool quota key: ${tool}`);

  await ensureUsageTable(db);
  const usageDate = todayUtc();

  await db.prepare('INSERT OR IGNORE INTO api_usage (tool, usage_date, count) VALUES (?, ?, 0)').bind(tool, usageDate).run();

  const beforeRow = await db.prepare('SELECT count FROM api_usage WHERE tool = ? AND usage_date = ? LIMIT 1').bind(tool, usageDate).first();
  const currentCount = Number(beforeRow?.count || 0);

  if (currentCount >= limit) {
    return { allowed: false, limit, count: currentCount, usageDate };
  }

  await db.prepare('UPDATE api_usage SET count = count + 1, updated_at = CURRENT_TIMESTAMP WHERE tool = ? AND usage_date = ?').bind(tool, usageDate).run();

  return { allowed: true, limit, count: currentCount + 1, usageDate };
}

export function quotaExceeded(limit, count) {
  return json({
    error: 'limit_reached',
    message: "Today's free AI limit is over. Please try again tomorrow.",
    limit,
    count,
  }, 429);
}

export function trimText(value, max = 1200) {
  return String(value || '').replace(/\s+/g, ' ').trim().slice(0, max);
}

export function trimMultiline(value, max = 4000) {
  return String(value || '').replace(/\r/g, '').trim().slice(0, max);
}

export function asArray(value, maxItems = 12) {
  if (Array.isArray(value)) return value.slice(0, maxItems).map((item) => trimText(item, 120));
  return [];
}

export function jsonStringFromGeminiResponse(payload) {
  const parts = payload?.candidates?.[0]?.content?.parts || [];
  const text = parts.map((part) => part?.text || '').join('').trim();
  return text || '';
}

export async function fetchGeminiJson({ apiKey, prompt, schema, temperature = 0.4, maxOutputTokens = 900, model = 'gemini-2.5-flash' }) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  const body = {
    contents: [{ parts: [{ text: prompt }] }],
    generationConfig: {
      temperature,
      maxOutputTokens,
      responseMimeType: 'application/json',
      responseJsonSchema: schema,
    },
  };

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      'x-goog-api-key': apiKey,
    },
    body: JSON.stringify(body),
  });

  const payload = await res.json().catch(() => null);
  if (!res.ok) {
    const detail = payload?.error?.message || payload?.error?.status || `Gemini request failed (${res.status}).`;
    throw new Error(detail);
  }

  const text = jsonStringFromGeminiResponse(payload);
  if (!text) throw new Error('Gemini returned an empty response.');
  return JSON.parse(text);
}

export async function fetchGroqJson({ apiKey, messages, model = 'llama-3.1-8b-instant', temperature = 0.7, maxCompletionTokens = 900 }) {
  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      temperature,
      max_completion_tokens: maxCompletionTokens,
      response_format: { type: 'json_object' },
    }),
  });

  const payload = await res.json().catch(() => null);
  if (!res.ok) {
    const detail = payload?.error?.message || `Groq request failed (${res.status}).`;
    throw new Error(detail);
  }

  const text = payload?.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error('Groq returned an empty response.');
  return JSON.parse(text);
}
