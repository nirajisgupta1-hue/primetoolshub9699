import {
  badRequest,
  configError,
  fetchGeminiJson,
  incrementUsage,
  json,
  parseJsonBody,
  quotaExceeded,
  trimMultiline,
  trimText,
  upstreamError,
} from '../_lib/api-utils.js';

const FAQ_SCHEMA = {
  type: 'object',
  properties: {
    intro: { type: 'string', description: 'A brief intro sentence for the FAQ section.' },
    faqs: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          question: { type: 'string' },
          answer: { type: 'string' }
        },
        required: ['question', 'answer']
      },
      description: 'A list of FAQ pairs.'
    }
  },
  required: ['intro', 'faqs']
};

export async function onRequestPost(context) {
  const apiKey = context.env.GEMINI_API_KEY;
  const db = context.env.DB;
  if (!apiKey) return configError('This AI tool is temporarily unavailable right now. Please try again later.');
  if (!db) return configError('This AI tool is temporarily unavailable right now. Please try again later.');

  const body = await parseJsonBody(context.request);
  if (!body) return badRequest('Please send a valid JSON body.');

  const topic = trimText(body.topic, 180);
  const summary = trimMultiline(body.summary, 2200);
  const audience = trimText(body.audience, 120);
  const tone = trimText(body.tone, 60);
  const region = trimText(body.region, 80);
  const keywords = trimText(body.keywords, 320);
  const faqCount = Math.max(4, Math.min(8, Number(body.faqCount || 6)));

  if (!topic || topic.length < 4) {
    return badRequest('Please enter the topic, page, product, or service for the FAQ section.');
  }

  const quota = await incrementUsage(db, 'ai_faq');
  if (!quota.allowed) return quotaExceeded(quota.limit, quota.count);

  const prompt = [
    'Generate clear FAQ content for a real public website page.',
    'Write questions a normal visitor would realistically ask after reading the page topic and summary.',
    'Keep the output page-specific. Avoid filler, repeated keyword variations, and generic SEO-style padding.',
    'Answers should be concise and practical, usually 30 to 80 words.',
    'Do not invent features, pricing, storage rules, privacy claims, timing promises, legal guarantees, or results unless the provided context clearly supports them.',
    'Do not output FAQ items that obviously belong to a different page type.',
    'If the context is thin, stay conservative and use broader but still useful wording.',
    `Topic: ${topic}`,
    `Audience: ${audience || 'General public'}`,
    `Tone: ${tone || 'Clear and friendly'}`,
    `Region or scope: ${region || 'Global'}`,
    `Keyword hints: ${keywords || 'None provided'}`,
    `Background summary: ${summary || 'None provided'}`,
    `Return ${faqCount} FAQ pairs.`
  ].join('\n');

  try {
    const result = await fetchGeminiJson({ apiKey, prompt, schema: FAQ_SCHEMA, temperature: 0.5, maxOutputTokens: 1100, model: 'gemini-2.5-flash' });
    if (!result || typeof result !== 'object') throw new Error('FAQ response was not valid JSON.');

    const faqs = Array.isArray(result.faqs)
      ? result.faqs.map((entry) => ({
          question: trimText(entry?.question, 180),
          answer: trimMultiline(entry?.answer, 520),
        })).filter((entry) => entry.question && entry.answer).slice(0, faqCount)
      : [];

    if (!faqs.length) throw new Error('FAQ response did not include any question and answer pairs.');

    const normalized = {
      intro: trimText(result.intro, 240),
      faqs,
    };

    return json(normalized, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
    });
  } catch (error) {
    return upstreamError('AI FAQ generation is temporarily unavailable. Please try again shortly.', error instanceof Error ? error.message : String(error));
  }
}
