import {
  badRequest,
  configError,
  fetchGeminiJson,
  incrementUsage,
  json,
  parseJsonBody,
  quotaExceeded,
  trimMultiline,
  trimText,
  upstreamError,
} from '../_lib/api-utils.js';

const SEO_SCHEMA = {
  type: 'object',
  properties: {
    seo_title: { type: 'string', description: 'An SEO title under about 60 characters when possible.' },
    meta_description: { type: 'string', description: 'A clickable meta description under about 155 characters when possible.' },
    h1: { type: 'string', description: 'A clear on-page heading.' },
    slug: { type: 'string', description: 'A lowercase URL slug using hyphens only.' },
    intro_paragraph: { type: 'string', description: 'A concise intro paragraph for the page.' },
    schema_description: { type: 'string', description: 'A short schema or OG description sentence.' },
    faq_ideas: {
      type: 'array',
      items: { type: 'string' },
      description: 'Four to six FAQ question ideas only, not full answers.'
    }
  },
  required: ['seo_title', 'meta_description', 'h1', 'slug', 'intro_paragraph', 'schema_description', 'faq_ideas']
};

export async function onRequestPost(context) {
  const apiKey = context.env.GEMINI_API_KEY;
  const db = context.env.DB;
  if (!apiKey) return configError('This AI tool is temporarily unavailable right now. Please try again later.');
  if (!db) return configError('This AI tool is temporarily unavailable right now. Please try again later.');

  const body = await parseJsonBody(context.request);
  if (!body) return badRequest('Please send a valid JSON body.');

  const topic = trimText(body.topic, 180);
  const pageType = trimText(body.pageType, 60);
  const brand = trimText(body.brand, 80);
  const audience = trimText(body.audience, 120);
  const region = trimText(body.region, 80);
  const keywords = trimText(body.keywords, 320);
  const summary = trimMultiline(body.summary, 2200);

  if (!topic || topic.length < 4) {
    return badRequest('Please enter the page topic or tool name.');
  }

  const quota = await incrementUsage(db, 'ai_seo');
  if (!quota.allowed) return quotaExceeded(quota.limit, quota.count);

  const prompt = [
    'Create clean, natural SEO page copy for a public tools website.',
    'Avoid keyword stuffing, hype, clickbait, and false claims.',
    'Prefer concise, clickable wording that still sounds believable.',
    'Do not invent claims such as free, no signup, instant, secure, best, or location details unless the provided input clearly supports them.',
    'Keep the title around 50-60 characters and the meta description around 140-155 characters when possible.',
    'Keep the H1 aligned with the title and page intent instead of switching to a different message.',
    'Return FAQ ideas that reflect real user questions the page could actually answer.',
    `Topic or page name: ${topic}`,
    `Page type: ${pageType || 'Tool page'}`,
    `Brand name: ${brand || 'Prime Tools Hub'}`,
    `Target audience: ${audience || 'General public'}`,
    `Primary region or audience scope: ${region || 'Global'}`,
    `Important keywords: ${keywords || 'None provided'}`,
    `Page summary or purpose: ${summary || 'None provided'}`,
    'Return practical output that can be pasted into title, meta, H1, intro, and FAQ planning.'
  ].join('\n');

  try {
    const result = await fetchGeminiJson({ apiKey, prompt, schema: SEO_SCHEMA, temperature: 0.4, maxOutputTokens: 850, model: 'gemini-2.5-flash' });
    if (!result || typeof result !== 'object') throw new Error('SEO response was not valid JSON.');

    const normalized = {
      seo_title: trimText(result.seo_title, 90),
      meta_description: trimText(result.meta_description, 220),
      h1: trimText(result.h1, 120),
      slug: trimText(result.slug, 120).toLowerCase().replace(/[^a-z0-9-]+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, ''),
      intro_paragraph: trimMultiline(result.intro_paragraph, 900),
      schema_description: trimText(result.schema_description, 220),
      faq_ideas: Array.isArray(result.faq_ideas) ? result.faq_ideas.map((item) => trimText(item, 160)).filter(Boolean).slice(0, 6) : [],
    };

    if (!normalized.seo_title || !normalized.meta_description) throw new Error('SEO response was missing the title or meta description.');

    return json(normalized, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
    });
  } catch (error) {
    return upstreamError('AI SEO generation is temporarily unavailable. Please try again shortly.', error instanceof Error ? error.message : String(error));
  }
}
