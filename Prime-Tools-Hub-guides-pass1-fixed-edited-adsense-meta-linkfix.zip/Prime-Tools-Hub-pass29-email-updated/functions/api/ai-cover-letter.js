import {
  badRequest,
  configError,
  fetchGeminiJson,
  incrementUsage,
  json,
  parseJsonBody,
  quotaExceeded,
  trimMultiline,
  trimText,
  upstreamError,
} from '../_lib/api-utils.js';

const COVER_SCHEMA = {
  type: 'object',
  properties: {
    subject_line: { type: 'string', description: 'A short email subject line when relevant.' },
    opening: { type: 'string', description: 'Opening paragraph or greeting block.' },
    main_body: { type: 'string', description: 'Main body paragraph or two.' },
    closing: { type: 'string', description: 'Closing paragraph with CTA or thanks.' },
    short_version: { type: 'string', description: 'A shorter version for quick replies or messages.' },
    key_highlights: { type: 'array', items: { type: 'string' }, description: 'Three to five short highlight points pulled from the user context.' },
    editing_note: { type: 'string', description: 'A short note telling the user what to review before sending.' }
  },
  required: ['subject_line', 'opening', 'main_body', 'closing', 'short_version', 'key_highlights', 'editing_note']
};

export async function onRequestPost(context) {
  const apiKey = context.env.GEMINI_API_KEY;
  const db = context.env.DB;
  if (!apiKey) return configError('This AI tool is temporarily unavailable right now. Please try again later.');
  if (!db) return configError('This AI tool is temporarily unavailable right now. Please try again later.');

  const body = await parseJsonBody(context.request);
  if (!body) return badRequest('Please send a valid JSON body.');

  const useCase = trimText(body.useCase, 80);
  const tone = trimText(body.tone, 80);
  const length = trimText(body.length, 40);
  const ctaGoal = trimText(body.ctaGoal, 180);
  const roleTitle = trimText(body.roleTitle, 120);
  const company = trimText(body.company, 120);
  const audience = trimText(body.audience, 100);
  const location = trimText(body.location, 120);
  const profile = trimMultiline(body.profile, 2200);
  const highlights = trimText(body.highlights, 320);
  const skills = trimText(body.skills, 320);
  const contextText = trimMultiline(body.context, 2400);

  if ((!roleTitle || roleTitle.length < 2) && (!contextText || contextText.length < 12)) {
    return badRequest('Please enter the role title or a little more message context.');
  }
  if (!profile || profile.length < 8) {
    return badRequest('Please enter a short profile or experience summary first.');
  }

  const quota = await incrementUsage(db, 'ai_cover_letter');
  if (!quota.allowed) return quotaExceeded(quota.limit, quota.count);

  const prompt = [
    'You are generating a structured professional writing draft for a public website tool.',
    'Keep the draft truthful, realistic, and clear.',
    'Do not invent achievements, dates, companies, or experience that the user did not provide.',
    'Avoid exaggerated claims, false urgency, or robotic filler.',
    `Use case: ${useCase || 'Cover letter'}`,
    `Tone: ${tone || 'Professional'}`,
    `Draft length: ${length || 'Medium'}`,
    `CTA or closing goal: ${ctaGoal || 'Polite next step'}`,
    `Role title: ${roleTitle || 'Not provided'}`,
    `Company or recipient: ${company || 'Not provided'}`,
    `Recipient type: ${audience || 'Not provided'}`,
    `Location or context: ${location || 'Not provided'}`,
    `User profile: ${profile}`,
    `Highlights: ${highlights || 'None provided'}`,
    `Skills: ${skills || 'None provided'}`,
    `Extra message or job context: ${contextText || 'None provided'}`,
    'Return a subject line, opening, main body, closing, short version, key highlights, and a short editing note.',
  ].join('
');

  try {
    const result = await fetchGeminiJson({ apiKey, prompt, schema: COVER_SCHEMA, temperature: 0.5, maxOutputTokens: 1350, model: 'gemini-2.5-flash' });
    if (!result || typeof result !== 'object') throw new Error('Cover-letter response was not valid JSON.');

    const normalized = {
      subject_line: trimText(result.subject_line, 160),
      opening: trimMultiline(result.opening, 700),
      main_body: trimMultiline(result.main_body, 1800),
      closing: trimMultiline(result.closing, 500),
      short_version: trimMultiline(result.short_version, 900),
      key_highlights: Array.isArray(result.key_highlights) ? result.key_highlights.map((item) => trimText(item, 200)).filter(Boolean).slice(0, 5) : [],
      editing_note: trimText(result.editing_note, 260),
    };

    if (!normalized.main_body) throw new Error('Draft response did not include the main body.');

    return json(normalized, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
    });
  } catch (error) {
    return upstreamError('AI cover letter generation is temporarily unavailable. Please try again shortly.', error instanceof Error ? error.message : String(error));
  }
}
