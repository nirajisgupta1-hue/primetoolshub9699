import {
  badRequest,
  fetchGeminiJson,
  fetchGroqJson,
  incrementUsage,
  json,
  parseJsonBody,
  quotaExceeded,
  trimMultiline,
  trimText,
} from '../_lib/api-utils.js';

const CAPTION_SCHEMA = {
  type: 'object',
  properties: {
    primary_caption: { type: 'string', description: 'A polished main caption.' },
    short_caption: { type: 'string', description: 'A shorter version of the caption.' },
    hook: { type: 'string', description: 'A short first-line hook.' },
    cta_line: { type: 'string', description: 'A short call-to-action line.' },
    hashtags: { type: 'array', items: { type: 'string' }, description: 'Five to ten hashtag strings starting with #.' },
    posting_note: { type: 'string', description: 'A short reminder about what to review before posting.' }
  },
  required: ['primary_caption', 'short_caption', 'hook', 'cta_line', 'hashtags', 'posting_note']
};

function normalizeTag(value) {
  const clean = String(value || '').trim().replace(/[^\w# ]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (!clean) return '';
  const compact = clean.toLowerCase().replace(/^#+/, '').replace(/\s+/g, '');
  return compact ? `#${compact.slice(0, 28)}` : '';
}

function buildLocalCaptionDraft({ topic, platform, tone, goal, audience, keywords, cta, emojiLevel, language }) {
  const cleanTopic = trimMultiline(topic, 700);
  const cleanPlatform = trimText(platform || 'social post', 40);
  const cleanTone = trimText(tone || 'clear', 40).toLowerCase();
  const cleanGoal = trimText(goal || 'engagement', 60);
  const cleanAudience = trimText(audience || 'your audience', 120);
  const cleanKeywords = trimText(keywords || '', 260);
  const cleanCta = trimText(cta || 'Learn more', 120);
  const cleanLanguage = trimText(language || 'English', 40);
  const emoji = /high/i.test(emojiLevel || '') ? '✨ ' : /medium/i.test(emojiLevel || '') ? '🔹 ' : '';

  const firstSentence = cleanTopic
    .split(/(?<=[.!?])\s+/)[0]
    .replace(/\s+/g, ' ')
    .trim();
  const trimmedFirst = firstSentence.length > 150 ? `${firstSentence.slice(0, 147).trim()}...` : firstSentence;
  const hook = trimText(`${emoji}${trimmedFirst || 'A clearer first draft for your next post.'}`, 180);

  const primaryParts = [
    hook,
    '',
    `Use this ${cleanPlatform} caption draft as a starting point for ${cleanAudience}.`,
    `Focus: ${cleanTopic}`,
    cleanKeywords ? `Key angle: ${cleanKeywords}.` : '',
    `Tone: ${cleanTone}. Goal: ${cleanGoal}.`,
    cleanCta ? `${cleanCta}.` : '',
  ].filter(Boolean);

  const shortParts = [
    hook,
    cleanKeywords ? `${cleanKeywords}.` : '',
    cleanCta ? `${cleanCta}.` : '',
  ].filter(Boolean);

  const keywordTags = cleanKeywords
    .split(',')
    .map((item) => normalizeTag(item))
    .filter(Boolean);
  const topicTags = cleanTopic
    .split(/[^A-Za-z0-9]+/)
    .filter((word) => word && word.length > 3)
    .slice(0, 4)
    .map((word) => normalizeTag(word));
  const fallbackTags = [
    normalizeTag(cleanPlatform),
    normalizeTag(cleanGoal),
    normalizeTag(cleanLanguage),
    '#contentdraft',
    '#socialcaption',
  ];
  const hashtags = [...new Set([...keywordTags, ...topicTags, ...fallbackTags])].filter(Boolean).slice(0, 8);

  return {
    primary_caption: trimMultiline(primaryParts.join('\n'), 1800),
    short_caption: trimMultiline(shortParts.join(' '), 800),
    hook,
    cta_line: trimText(cleanCta || 'Review the draft, then post only what matches the real offer.', 180),
    hashtags,
    posting_note: trimText('Review claims, dates, pricing, hashtags, and brand tone before posting anything live.', 220),
  };
}

function normalizeResult(result) {
  return {
    primary_caption: trimMultiline(result?.primary_caption, 1800),
    short_caption: trimMultiline(result?.short_caption, 800),
    hook: trimText(result?.hook, 180),
    cta_line: trimText(result?.cta_line, 180),
    hashtags: Array.isArray(result?.hashtags)
      ? result.hashtags.map((tag) => normalizeTag(tag)).filter(Boolean).slice(0, 10)
      : [],
    posting_note: trimText(result?.posting_note, 220),
  };
}

export async function onRequestPost(context) {
  const groqKey = context.env.GROQ_API_KEY;
  const geminiKey = context.env.GEMINI_API_KEY;
  const db = context.env.DB;

  const body = await parseJsonBody(context.request);
  if (!body) return badRequest('Please send a valid JSON body.');

  const topic = trimMultiline(body.topic, 1200);
  const platform = trimText(body.platform, 40);
  const tone = trimText(body.tone, 40);
  const language = trimText(body.language, 40);
  const goal = trimText(body.goal, 60);
  const audience = trimText(body.audience, 120);
  const keywords = trimText(body.keywords, 260);
  const cta = trimText(body.cta, 120);
  const emojiLevel = trimText(body.emojiLevel, 40);

  if (!topic || topic.length < 8) {
    return badRequest('Please enter the post idea, product, topic, or brief in a little more detail.');
  }

  let quota = null;
  if (db) {
    try {
      quota = await incrementUsage(db, 'ai_caption');
      if (!quota.allowed) return quotaExceeded(quota.limit, quota.count);
    } catch {
      quota = null;
    }
  }

  const messages = [
    {
      role: 'system',
      content: [
        'You generate social media captions for a public website tool.',
        'Return only one valid JSON object.',
        'Do not wrap the response in markdown or code fences.',
        'Use exactly these keys: primary_caption, short_caption, hook, cta_line, hashtags, posting_note.',
        'hashtags must be an array of 5 to 10 hashtag strings starting with #.',
        'primary_caption should feel polished and natural.',
        'short_caption should be compact.',
        'Keep claims realistic and avoid spammy wording.'
      ].join(' '),
    },
    {
      role: 'user',
      content: [
        `Platform: ${platform || 'General social post'}`,
        `Tone: ${tone || 'Balanced'}`,
        `Language style: ${language || 'English'}`,
        `Goal: ${goal || 'Engagement'}`,
        `Audience: ${audience || 'General audience'}`,
        `Keywords or hooks: ${keywords || 'None provided'}`,
        `CTA preference: ${cta || 'Soft CTA'}`,
        `Emoji level: ${emojiLevel || 'Medium'}`,
        'Create caption ideas from this brief:',
        topic,
      ].join('\n'),
    },
  ];

  let result = null;
  try {
    if (groqKey) {
      result = await fetchGroqJson({ apiKey: groqKey, messages, model: 'llama-3.1-8b-instant', temperature: 0.8, maxCompletionTokens: 700 });
    } else if (geminiKey) {
      const prompt = [
        'You generate social media captions for a public website tool.',
        'Return only valid JSON that matches the requested schema.',
        'Keep the wording natural, specific, and not spammy.',
        'Do not invent discounts, deadlines, features, or claims that the prompt does not support.',
        `Platform: ${platform || 'General social post'}`,
        `Tone: ${tone || 'Balanced'}`,
        `Language style: ${language || 'English'}`,
        `Goal: ${goal || 'Engagement'}`,
        `Audience: ${audience || 'General audience'}`,
        `Keywords or hooks: ${keywords || 'None provided'}`,
        `CTA preference: ${cta || 'Soft CTA'}`,
        `Emoji level: ${emojiLevel || 'Medium'}`,
        'Create caption ideas from this brief:',
        topic,
      ].join('\n');
      result = await fetchGeminiJson({ apiKey: geminiKey, prompt, schema: CAPTION_SCHEMA, temperature: 0.7, maxOutputTokens: 850, model: 'gemini-2.5-flash' });
    }
  } catch {
    result = null;
  }

  const normalized = normalizeResult(result);
  const finalPayload = normalized.primary_caption
    ? normalized
    : buildLocalCaptionDraft({ topic, platform, tone, goal, audience, keywords, cta, emojiLevel, language });

  return json(finalPayload, 200, quota ? {
    'x-pt-limit': String(quota.limit),
    'x-pt-count': String(quota.count),
  } : {});
}
