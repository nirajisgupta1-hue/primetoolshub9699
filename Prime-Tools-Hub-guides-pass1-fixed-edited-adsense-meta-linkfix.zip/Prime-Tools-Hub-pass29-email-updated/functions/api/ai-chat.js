import {
  badRequest,
  configError,
  fetchGeminiJson,
  incrementUsage,
  json,
  parseJsonBody,
  quotaExceeded,
  trimMultiline,
  trimText,
  upstreamError,
} from '../_lib/api-utils.js';

const CHAT_SCHEMA = {
  type: 'object',
  properties: {
    headline: { type: 'string', description: 'A short label for the answer.' },
    answer: { type: 'string', description: 'The main response body.' },
    bullet_points: { type: 'array', items: { type: 'string' }, description: 'Three to six helpful supporting points.' },
    next_steps: { type: 'array', items: { type: 'string' }, description: 'Two to five practical next steps.' },
    follow_up_prompts: { type: 'array', items: { type: 'string' }, description: 'Two to four optional follow-up prompts the user could ask next.' },
    caution: { type: 'string', description: 'A short review reminder or caution note.' }
  },
  required: ['headline', 'answer', 'bullet_points', 'next_steps', 'follow_up_prompts', 'caution']
};

export async function onRequestPost(context) {
  const apiKey = context.env.GEMINI_API_KEY;
  const db = context.env.DB;
  if (!apiKey) return configError('This AI tool is temporarily unavailable right now. Please try again later.');
  if (!db) return configError('This AI tool is temporarily unavailable right now. Please try again later.');

  const body = await parseJsonBody(context.request);
  if (!body) return badRequest('Please send a valid JSON body.');

  const prompt = trimMultiline(body.prompt, 2600);
  const mode = trimText(body.mode, 80);
  const tone = trimText(body.tone, 80);
  const length = trimText(body.length, 40);
  const language = trimText(body.language, 60);
  const audience = trimText(body.audience, 120);
  const goal = trimText(body.goal, 180);
  const extraContext = trimMultiline(body.context, 2200);

  if (!prompt || prompt.length < 8) {
    return badRequest('Please enter a little more detail for the chat request.');
  }

  const quota = await incrementUsage(db, 'ai_chat');
  if (!quota.allowed) return quotaExceeded(quota.limit, quota.count);

  const finalPrompt = [
    'You are generating structured output for a public browser-based AI chat helper.',
    'Give practical, grounded help. Keep wording clear and not overly robotic.',
    'If the user asks for something risky, illegal, or unsafe, keep the response high-level and redirect toward safer guidance.',
    'Do not use markdown code fences or headings in the answer field.',
    `Mode: ${mode || 'General help'}`,
    `Tone: ${tone || 'Clear and friendly'}`,
    `Length: ${length || 'Medium'}`,
    `Language style: ${language || 'English'}`,
    `Audience: ${audience || 'General audience'}`,
    `Goal: ${goal || 'Help the user clearly'}`,
    `Extra context: ${extraContext || 'None provided'}`,
    'Create a short headline, one main answer, supporting bullet points, next steps, follow-up prompts, and a short review note.',
    'User request:',
    prompt,
  ].join('
');

  try {
    const result = await fetchGeminiJson({ apiKey, prompt: finalPrompt, schema: CHAT_SCHEMA, temperature: 0.55, maxOutputTokens: 1300, model: 'gemini-2.5-flash' });
    if (!result || typeof result !== 'object') throw new Error('AI chat response was not valid JSON.');

    const normalized = {
      headline: trimText(result.headline, 120),
      answer: trimMultiline(result.answer, 2400),
      bullet_points: Array.isArray(result.bullet_points) ? result.bullet_points.map((item) => trimText(item, 220)).filter(Boolean).slice(0, 6) : [],
      next_steps: Array.isArray(result.next_steps) ? result.next_steps.map((item) => trimText(item, 220)).filter(Boolean).slice(0, 5) : [],
      follow_up_prompts: Array.isArray(result.follow_up_prompts) ? result.follow_up_prompts.map((item) => trimText(item, 220)).filter(Boolean).slice(0, 4) : [],
      caution: trimText(result.caution, 240),
    };

    if (!normalized.answer) throw new Error('AI chat response did not include the main answer.');

    return json(normalized, 200, {
      'x-pt-limit': String(quota.limit),
      'x-pt-count': String(quota.count),
    });
  } catch (error) {
    return upstreamError('AI chat generation is temporarily unavailable. Please try again shortly.', error instanceof Error ? error.message : String(error));
  }
}
