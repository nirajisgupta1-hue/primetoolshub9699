document.addEventListener("DOMContentLoaded", function () {
  const searchInput = document.getElementById("searchInput");
  const suggestBox = document.getElementById("searchSuggest");

  if (!searchInput || !suggestBox) return;

  function norm(value) {
    return String(value || "").toLowerCase().trim();
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function makeItem(title, href, keywords, ico, kind, group, desc) {
    return { title, href, keywords, ico, kind, group, desc };
  }

  const allTools = [
    makeItem("AI Tools", "/tools/ai-tools", "ai tools chat assistant cover letter reply helper caption generator seo meta faq generator ai workflow", "fa-solid fa-robot", "Category", "Categories", "AI chat, writing, caption, SEO, FAQ, and future workflow helpers."),
    makeItem("AI Caption Generator", "/tools/ai-caption-generator", "ai caption generator instagram facebook youtube social hook", "fa-solid fa-hashtag", "Tool", "AI Tools", "Generate social captions, hooks, CTA lines, and hashtags."),
    makeItem("AI SEO Title & Meta Generator", "/tools/ai-seo-meta-generator", "ai seo title meta description faq generator", "fa-solid fa-magnifying-glass-chart", "Tool", "AI Tools", "Generate titles, meta descriptions, slugs, intros, and FAQ ideas."),
    makeItem("AI FAQ Generator", "/tools/ai-faq-generator", "ai faq generator faq writer schema json ld", "fa-solid fa-circle-question", "Tool", "AI Tools", "Generate FAQ questions, answers, and copy-ready FAQ schema text."),
    makeItem("AI Chat Assistant", "/tools/ai-chat-assistant", "ai chat assistant chatbot prompt helper answer rewrite summarize", "fa-solid fa-comments", "Tool", "AI Tools", "Ask questions, rewrite text, summarize notes, and get step-by-step help."),
    makeItem("AI Cover Letter & Reply Helper", "/tools/ai-cover-letter-reply-helper", "ai cover letter email reply professional writing helper recruiter follow up", "fa-solid fa-file-lines", "Tool", "AI Tools", "Draft cover letters, recruiter replies, and professional messages."),
    makeItem("AI Study Notes Summarizer", "/tools/ai-tools#ai-study-notes-summarizer", "ai study notes summarizer revision bullets quiz", "fa-solid fa-book-open-reader", "Tool", "AI Tools", "Planned AI summarizer for study notes and revision."),
    makeItem("AI Image Caption & Alt Text Tool", "/tools/ai-tools#ai-image-alt-text-tool", "ai image caption alt text accessibility summary vision", "fa-solid fa-image", "Tool", "AI Tools", "Planned AI image understanding and alt-text helper."),
    makeItem("Real Estate Tools", "/tools/real-estate", "real estate land property plot area circle rate stamp duty home affordability closing costs rent buy sale proceeds", "fa-solid fa-house", "Category", "Categories", "Land, property, affordability and home-planning calculators."),
    makeItem("Finance Calculators", "/tools/finance", "finance gst tax investment fd sip percentage discount margin currency crypto sales tax tip", "fa-solid fa-coins", "Category", "Categories", "Tax, money, billing, savings and pricing calculators."),
    makeItem("World Finance & Mortgage", "/tools/world-finance-mortgage", "world finance mortgage amortization lease paycheck loan salary global", "fa-solid fa-globe", "Category", "Categories", "Mortgage, amortization, lease and paycheck tools."),
    makeItem("Personal & Health", "/tools/personal-health", "personal health calorie bmi bmr age body fat tdee macro water anniversary", "fa-solid fa-heart-pulse", "Category", "Categories", "Age, wellness, nutrition and body-metric tools."),
    makeItem("Job & Career Tools", "/tools/job-tools", "job career resume cover letter word counter cv qr", "fa-solid fa-briefcase", "Category", "Categories", "Resume, cover letter and writing-support tools."),
    makeItem("PDF Tools", "/tools/pdf-tools", "pdf tools merge split rotate reorder extract image to pdf text to pdf convert", "fa-solid fa-file-pdf", "Category", "Categories", "Create, convert and manage PDF files."),
    makeItem("Image & Utility Tools", "/tools/image-utility", "image Prime qr barcode password favicon color picker background remover mask converter", "fa-solid fa-image", "Category", "Categories", "Image helpers, QR tools and Prime generators."),
    makeItem("Social Media Tools", "/tools/social", "social media captions hashtags bio fancy text username linkedin youtube", "fa-solid fa-hashtag", "Category", "Categories", "Creator tools for bios, captions and social text."),
    makeItem("Student & Academic Tools", "/tools/student-academic", "student academic study planner gpa revision", "fa-solid fa-graduation-cap", "Category", "Categories", "Study-planning and academic support tools."),
    makeItem("Travel & Visa Tools", "/tools/travel-visa-tools", "travel visa passport timezone packing budget flight", "fa-solid fa-plane-departure", "Category", "Categories", "Visa prep, trip planning and travel helpers."),
    makeItem("Fun Tools", "/tools/fun-tools", "fun random spin wheel giveaway picker reaction cps santa movie watch", "fa-solid fa-gamepad", "Category", "Categories", "Wheels, pickers, tests and random generators."),

    makeItem("Gaj to Square Feet", "/tools/gaj-to-sqft", "gaj square feet converter land plot property measurement", "fa-solid fa-ruler-combined", "Tool", "Real Estate Tools", "Convert Gaj into Square Feet instantly."),
    makeItem("Bigha to Acre Converter", "/tools/bigha-to-acre", "bigha acre converter rural land agriculture property", "fa-solid fa-earth-asia", "Tool", "Real Estate Tools", "Convert Bigha to Acre for land measurements."),
    makeItem("Square Meter to Sq Ft", "/tools/sqm-to-sqft", "square meter to sqft converter metric land property", "fa-solid fa-expand", "Tool", "Real Estate Tools", "Quick metric-to-imperial area conversion."),
    makeItem("Plot Area Cost Calculator", "/tools/plot-cost", "plot cost area rate land value calculator", "fa-solid fa-indian-rupee-sign", "Tool", "Real Estate Tools", "Estimate total plot cost using area and rate."),
    makeItem("Plot Area Calculator", "/tools/plot-area-calculator", "plot area calculator length width land size", "fa-solid fa-draw-polygon", "Tool", "Real Estate Tools", "Calculate area from length and width."),
    makeItem("Stamp Duty & Registration", "/tools/stamp-duty-calculator", "stamp duty registration charges property purchase fees", "fa-solid fa-file-signature", "Tool", "Real Estate Tools", "Estimate stamp duty and registration charges."),
    makeItem("Land Unit Mega Converter", "/tools/land-unit-converter", "land unit converter sqft sqm acre hectare bigha gaj", "fa-solid fa-arrows-rotate", "Tool", "Real Estate Tools", "Convert multiple land units in one place."),
    makeItem("Circle Rate Calculator", "/tools/circle-rate-calculator", "circle rate plot value land property valuation", "fa-solid fa-building-circle-check", "Tool", "Real Estate Tools", "Estimate plot value using circle rate."),
    makeItem("Home Affordability Calculator", "/tools/home-affordability-calculator", "home affordability house budget property buying", "fa-solid fa-house-chimney", "Tool", "Real Estate Tools", "Check affordable home-buying range."),
    makeItem("Home Loan EMI Calculator", "/tools/home-loan-emi", "home loan emi mortgage loan payment property", "fa-solid fa-money-check-dollar", "Tool", "Real Estate Tools", "Calculate monthly home-loan EMI."),
    makeItem("Rent vs Buy Calculator", "/tools/rent-vs-buy-calculator", "rent vs buy property home compare housing", "fa-solid fa-scale-balanced", "Tool", "Real Estate Tools", "Compare renting and buying costs."),
    makeItem("World Rent vs Buy Calculator", "/tools/usa-rent-vs-buy", "world rent vs buy housing compare mortgage global", "fa-solid fa-earth-americas", "Tool", "Real Estate Tools", "Broader rent-vs-buy comparison workflow."),
    makeItem("Home Sale Proceeds Calculator", "/tools/home-sale-proceeds-calculator", "home sale proceeds seller net value calculator", "fa-solid fa-sack-dollar", "Tool", "Real Estate Tools", "Estimate likely amount after a property sale."),
    makeItem("Closing Costs Calculator", "/tools/closing-costs-calculator", "closing costs buyer fees property purchase cash to close", "fa-solid fa-file-invoice-dollar", "Tool", "Real Estate Tools", "Plan buyer-side closing costs and fees."),

    makeItem("GST Invoice Generator (India) + PDF", "/tools/gst-invoice-generator-india-pdf", "gst invoice generator india pdf tax invoice bill business", "fa-solid fa-file-invoice-dollar", "Tool", "Finance Calculators", "Create GST invoices with PDF-friendly output."),
    makeItem("Compound Interest", "/tools/compound-interest", "compound interest investment growth calculator", "fa-solid fa-chart-simple", "Tool", "Finance Calculators", "Estimate investment growth over time."),
    makeItem("SIP Calculator", "/tools/sip-calculator", "sip calculator monthly investment mutual fund return", "fa-solid fa-chart-line", "Tool", "Finance Calculators", "Plan monthly investments and future corpus."),
    makeItem("Currency Converter", "/tools/currency-converter", "currency converter forex exchange money", "fa-solid fa-money-bill-transfer", "Tool", "Finance Calculators", "Convert currencies for payments and travel."),
    makeItem("Crypto Converter", "/tools/crypto-converter", "crypto converter bitcoin ethereum coin fiat", "fa-brands fa-bitcoin", "Tool", "Finance Calculators", "Convert crypto values quickly."),
    makeItem("FD Maturity Calculator", "/tools/fd-calculator", "fd maturity calculator fixed deposit interest", "fa-solid fa-piggy-bank", "Tool", "Finance Calculators", "Check maturity amount and earned interest."),
    makeItem("GST Calculator", "/tools/gst-calculator", "gst tax add remove net amount", "fa-solid fa-receipt", "Tool", "Finance Calculators", "Add or remove GST instantly."),
    makeItem("Discount Calculator", "/tools/discount-calculator", "discount calculator savings final price", "fa-solid fa-tags", "Tool", "Finance Calculators", "Estimate savings and final discounted price."),
    makeItem("Profit Margin Calculator", "/tools/profit-margin", "profit margin selling price business", "fa-solid fa-coins", "Tool", "Finance Calculators", "Check profit amount and margin percentage."),
    makeItem("Income Tax Calculator", "/tools/income-tax-calculator", "income tax taxable income tax planning", "fa-solid fa-file-invoice-dollar", "Tool", "Finance Calculators", "Estimate taxable income and tax burden."),
    makeItem("FD vs SIP Comparison", "/tools/fd-vs-sip", "fd vs sip compare investment returns", "fa-solid fa-scale-balanced", "Tool", "Finance Calculators", "Compare fixed deposit and SIP outcomes."),
    makeItem("Percentage Calculator", "/tools/percentage-calculator", "percentage calculator increase decrease part value", "fa-solid fa-percent", "Tool", "Finance Calculators", "Calculate percentage changes quickly."),
    makeItem("Sales Tax Calculator", "/tools/usa-sales-tax", "sales tax calculator purchase total tax amount", "fa-solid fa-receipt", "Tool", "Finance Calculators", "Estimate purchase tax and final total."),
    makeItem("Tip Calculator", "/tools/usa-tip-calculator", "tip calculator split bill restaurant gratuity", "fa-solid fa-hand-holding-dollar", "Tool", "Finance Calculators", "Split bills and add service tip quickly."),

    makeItem("Amortization Schedule", "/tools/usa-amortization", "amortization schedule principal interest balance loan", "fa-solid fa-table-list", "Tool", "World Finance & Mortgage", "View loan repayment breakdown over time."),
    makeItem("Lease Calculator", "/tools/usa-lease-calculator", "lease calculator car lease monthly cost", "fa-solid fa-car-side", "Tool", "World Finance & Mortgage", "Estimate lease payment and overall lease cost."),
    makeItem("Mortgage Calculator", "/tools/usa-mortgage-calculator", "mortgage calculator monthly payment interest house loan", "fa-solid fa-house-chimney", "Tool", "World Finance & Mortgage", "Estimate mortgage payments and total repayment."),
    makeItem("Paycheck Calculator", "/tools/usa-paycheck-calculator", "paycheck calculator salary take home deductions", "fa-solid fa-wallet", "Tool", "World Finance & Mortgage", "Estimate take-home pay and deductions."),

    makeItem("Age Calculator", "/tools/age-calculator-pro", "age calculator birthday dob years months days", "fa-solid fa-calendar-days", "Tool", "Personal & Health", "Calculate exact age from date of birth."),
    makeItem("Anniversary Calculator", "/tools/anniversary-calculator", "anniversary calculator milestone date tracking", "fa-solid fa-heart", "Tool", "Personal & Health", "Track anniversary duration and milestones."),
    makeItem("Calorie Calculator", "/tools/calorie-calculator", "calorie calculator maintenance weight loss diet", "fa-solid fa-fire", "Tool", "Personal & Health", "Estimate daily calorie needs."),
    makeItem("BMI + BMR Calculator", "/tools/bmi-bmr-calculator", "bmi bmr calculator body mass basal metabolic rate", "fa-solid fa-heart-pulse", "Tool", "Personal & Health", "Check BMI and BMR in one tool."),
    makeItem("Water Intake Calculator", "/tools/water-intake-calculator", "water intake hydration daily water", "fa-solid fa-glass-water", "Tool", "Personal & Health", "Estimate daily hydration target."),
    makeItem("Body Fat Calculator", "/tools/body-fat-calculator", "body fat calculator body fat percentage", "fa-solid fa-percent", "Tool", "Personal & Health", "Estimate body fat percentage."),
    makeItem("TDEE Calculator", "/tools/tdee-calculator", "tdee calculator total daily energy expenditure", "fa-solid fa-bolt", "Tool", "Personal & Health", "Estimate daily energy expenditure."),
    makeItem("Ideal Weight Calculator", "/tools/ideal-weight-calculator", "ideal weight calculator healthy weight range", "fa-solid fa-weight-scale", "Tool", "Personal & Health", "Check a healthy estimated weight range."),
    makeItem("Macro Calculator", "/tools/macro-calculator", "macro calculator protein carbs fat nutrition", "fa-solid fa-utensils", "Tool", "Personal & Health", "Estimate protein, carbs and fat targets."),

    makeItem("India Resume Builder + QR", "/tools/india-resume-builder-qr", "india resume builder qr ats cv pdf", "fa-solid fa-file-signature", "Tool", "Job & Career Tools", "Build an India-focused resume with QR support."),
    makeItem("USA Resume Builder + QR", "/tools/usa-resume-builder", "usa resume builder qr ats cv pdf", "fa-solid fa-file-lines", "Tool", "Job & Career Tools", "Build a US-style resume with QR support."),
    makeItem("Cover Letter Builder + PDF", "/tools/cover-letter-builder-pdf", "cover letter builder pdf job application", "fa-solid fa-envelope-open-text", "Tool", "Job & Career Tools", "Build structured cover letters with PDF output."),
    makeItem("Word Counter", "/tools/word-counter", "word counter character counter text length reading time", "fa-solid fa-keyboard", "Tool", "Job & Career Tools", "Count words, characters and text length quickly."),

    makeItem("PDF to Office Converter", "/tools/pdf-to-office-converter", "pdf to docx doc pptx xlsx office converter word powerpoint excel", "fa-solid fa-file-export", "Tool", "PDF Tools", "Convert text-based PDFs into editable Office-style files."),
    makeItem("PDF to JSON, Watermark & Metadata Editor", "/tools/pdf-json-watermark-metadata", "pdf to json watermark metadata editor add watermark edit pdf metadata title author subject keywords", "fa-solid fa-file-shield", "Tool", "PDF Tools", "Export PDF content as JSON, add watermarks, and edit metadata in one page."),
    makeItem("Image to PDF", "/tools/image-to-pdf", "image to pdf convert images pdf", "fa-solid fa-file-arrow-up", "Tool", "PDF Tools", "Convert images into a PDF file."),
    makeItem("Text to PDF", "/tools/text-to-pdf", "text to pdf converter", "fa-solid fa-file-lines", "Tool", "PDF Tools", "Turn plain text into a clean PDF."),
    makeItem("PDF to JPG Converter", "/tools/pdf-to-jpg", "pdf to jpg image converter", "fa-solid fa-file-image", "Tool", "PDF Tools", "Convert PDF pages into JPG images."),
    makeItem("Merge PDF", "/tools/merge-pdf", "merge pdf combine pdf files", "fa-solid fa-object-group", "Tool", "PDF Tools", "Combine multiple PDFs into one file."),
    makeItem("Split PDF", "/tools/split-pdf", "split pdf extract pages", "fa-solid fa-scissors", "Tool", "PDF Tools", "Split PDF pages or selected ranges."),
    makeItem("PDF to PNG", "/tools/pdf-to-png", "pdf to png converter", "fa-solid fa-file-image", "Tool", "PDF Tools", "Convert PDF pages into PNG images."),
    makeItem("Rotate PDF", "/tools/rotate-pdf", "rotate pdf pages orientation", "fa-solid fa-rotate-right", "Tool", "PDF Tools", "Rotate PDF pages before downloading."),
    makeItem("Reorder PDF Pages", "/tools/reorder-pdf-pages", "reorder pdf pages rearrange page order", "fa-solid fa-arrow-right-arrow-left", "Tool", "PDF Tools", "Change PDF page order visually."),
    makeItem("Extract PDF Pages", "/tools/extract-pdf-pages", "extract pdf pages selected range", "fa-solid fa-file-export", "Tool", "PDF Tools", "Extract selected pages into a smaller PDF."),

    makeItem("Aadhaar/PAN Mask (Blur)", "/tools/aadhaar-pan-mask", "aadhaar pan blur mask sensitive id", "fa-solid fa-user-shield", "Tool", "Image & Utility Tools", "Mask sensitive details before sharing documents."),
    makeItem("Barcode Generator", "/tools/barcode-generator", "barcode generator labels product code", "fa-solid fa-barcode", "Tool", "Image & Utility Tools", "Generate barcode visuals for labels and products."),
    makeItem("Color Picker (Image)", "/tools/color-picker-image", "color picker image hex rgb eyedropper", "fa-solid fa-eye-dropper", "Tool", "Image & Utility Tools", "Pick exact colors from uploaded images."),
    makeItem("Favicon Generator", "/tools/favicon-generator", "favicon generator site icon", "fa-solid fa-icons", "Tool", "Image & Utility Tools", "Create favicon-ready icons for websites."),
    makeItem("Image Compressor", "/tools/image-compressor", "image compressor reduce size kb mb", "fa-solid fa-compress", "Tool", "Image & Utility Tools", "Reduce image size for faster uploads."),
    makeItem("Image Resizer + Cropper", "/tools/image-resizer-cropper", "image resizer cropper resize crop", "fa-solid fa-crop-simple", "Tool", "Image & Utility Tools", "Resize and crop images easily."),
    makeItem("JPG ↔ PNG Converter", "/tools/jpg-png-converter", "jpg png converter image format", "fa-solid fa-right-left", "Tool", "Image & Utility Tools", "Convert between JPG and PNG formats."),
    makeItem("Password Generator", "/tools/password-generator", "password generator strong random secure", "fa-solid fa-key", "Tool", "Image & Utility Tools", "Generate strong random passwords."),
    makeItem("QR Code Generator", "/tools/qr-code-generator", "qr code generator create qr", "fa-solid fa-qrcode", "Tool", "Image & Utility Tools", "Create QR codes for links and text."),
    makeItem("Background Remover", "/tools/usa-background-remover", "background remover photo cutout transparent", "fa-solid fa-image-portrait", "Tool", "Image & Utility Tools", "Remove image backgrounds quickly."),

    makeItem("Bio Line Generator", "/tools/bio-line-generator", "bio line generator profile bio branding", "fa-solid fa-user-pen", "Tool", "Social Media Tools", "Create short catchy bio lines for profiles."),
    makeItem("Emoji Combos Generator", "/tools/emoji-combos", "emoji combos generator social text", "fa-solid fa-face-smile", "Tool", "Social Media Tools", "Generate emoji combinations for bios and captions."),
    makeItem("Fancy Text Generator", "/tools/fancy-text", "fancy text generator stylish text", "fa-solid fa-font", "Tool", "Social Media Tools", "Turn normal text into stylish variations."),
    makeItem("Hashtag Generator", "/tools/hashtag-generator", "hashtag generator post reach social", "fa-solid fa-hashtag", "Tool", "Social Media Tools", "Generate relevant hashtags for posts and reels."),
    makeItem("Instagram Caption Generator", "/tools/instagram-caption-generator", "instagram caption generator insta captions", "fa-brands fa-instagram", "Tool", "Social Media Tools", "Create ready-to-use Instagram caption ideas."),
    makeItem("LinkedIn Headline Generator", "/tools/linkedin-headline-generator", "linkedin headline generator professional branding", "fa-brands fa-linkedin", "Tool", "Social Media Tools", "Create stronger LinkedIn headline ideas."),
    makeItem("Stylish Name Generator", "/tools/stylish-name", "stylish name generator profile name gaming", "fa-solid fa-signature", "Tool", "Social Media Tools", "Generate stylish name formats for profiles."),
    makeItem("Username Generator", "/tools/username-generator", "username generator social handle gaming", "fa-solid fa-at", "Tool", "Social Media Tools", "Generate username ideas for social accounts."),
    makeItem("YouTube Title Generator", "/tools/youtube-title-generator", "youtube title generator shorts video", "fa-brands fa-youtube", "Tool", "Social Media Tools", "Create stronger title ideas for videos and shorts."),

    makeItem("Study Planner + Revision", "/tools/study-planner-india", "study planner revision exam schedule academic", "fa-solid fa-calendar-check", "Tool", "Student & Academic Tools", "Create study plans and revision routines."),
    makeItem("GPA Calculator", "/tools/usa-gpa-calculator", "gpa calculator grades academic", "fa-solid fa-square-poll-vertical", "Tool", "Student & Academic Tools", "Calculate grade point average quickly."),

    makeItem("Passport / Visa Photo Maker", "/tools/passport-visa-photo-maker", "passport visa photo maker travel document", "fa-solid fa-camera-retro", "Tool", "Travel & Visa Tools", "Create passport and visa-style photos."),
    makeItem("Time Zone Meeting Planner", "/tools/time-zone-meeting-planner", "time zone meeting planner world clock", "fa-solid fa-globe", "Tool", "Travel & Visa Tools", "Compare global time zones for meetings."),
    makeItem("Flight Price Tracker", "/tools/flight-price-tracker", "flight price tracker airfare travel", "fa-solid fa-plane-up", "Tool", "Travel & Visa Tools", "Track route timing and airfare ideas."),
    makeItem("Travel Budget Calculator", "/tools/travel-budget-calculator", "travel budget calculator trip cost", "fa-solid fa-suitcase-rolling", "Tool", "Travel & Visa Tools", "Estimate total trip spending."),
    makeItem("Packing List Generator", "/tools/packing-list-generator", "packing list generator travel checklist", "fa-solid fa-suitcase", "Tool", "Travel & Visa Tools", "Create packing checklists for trips."),
    makeItem("Flight Battery Rule Checker", "/tools/power-bank-flight-rule-checker", "power bank flight battery rule checker airline", "fa-solid fa-battery-full", "Tool", "Travel & Visa Tools", "Check carry rules for batteries and power banks."),
    makeItem("Event Time Announcer", "/tools/event-time-announcer", "event time announcer webinar timezone", "fa-solid fa-bullhorn", "Tool", "Travel & Visa Tools", "Announce event times clearly across time zones."),

    makeItem("CPS Test", "/tools/cps-test", "cps test clicks per second speed", "fa-solid fa-hand-pointer", "Tool", "Fun Tools", "Check clicks per second for fun speed testing."),
    makeItem("Funny Name Generator", "/tools/funny-name-generator", "funny name generator random names", "fa-solid fa-face-laugh", "Tool", "Fun Tools", "Create silly and entertaining names."),
    makeItem("Gamer Name Generator", "/tools/gamer-name-generator", "gamer name generator gaming nickname", "fa-solid fa-ghost", "Tool", "Fun Tools", "Generate cool gaming-style names."),
    makeItem("Giveaway Winner Picker", "/tools/giveaway-winner-picker", "giveaway winner picker random winner", "fa-solid fa-gift", "Tool", "Fun Tools", "Pick winners randomly for giveaways and contests."),
    makeItem("Movie Picker Wheel", "/tools/movie-picker-wheel", "movie picker wheel what to watch", "fa-solid fa-film", "Tool", "Fun Tools", "Spin to choose what to watch."),
    makeItem("Random Name Picker", "/tools/random-name-picker", "random name picker classroom teams", "fa-solid fa-user-group", "Tool", "Fun Tools", "Choose names randomly for groups and games."),
    makeItem("Reaction Time Test", "/tools/reaction-time-test", "reaction time test reflex speed", "fa-solid fa-stopwatch", "Tool", "Fun Tools", "Measure how quickly you respond."),
    makeItem("Secret Santa Generator", "/tools/secret-santa-generator", "secret santa generator holiday gift match", "fa-solid fa-hat-santa", "Tool", "Fun Tools", "Generate secret gift matches for groups."),
    makeItem("Spin Wheel", "/tools/spin-wheel", "spin wheel random decision", "fa-solid fa-circle-notch", "Tool", "Fun Tools", "Use a customizable wheel for random picks."),
    makeItem("Stopwatch & Timer", "/tools/stopwatch-timer", "stopwatch timer countdown", "fa-solid fa-stopwatch-20", "Tool", "Fun Tools", "Use a simple stopwatch and countdown timer."),
    makeItem("What Should I Watch?", "/tools/what-should-i-watch", "what should i watch movie show picker", "fa-solid fa-tv", "Tool", "Fun Tools", "Get fun watch suggestions quickly."),
    makeItem("Business Tools", "/tools/business-tools", "business tools invoice signature gst billing email business workflow", "fa-solid fa-briefcase", "Category", "Categories", "Invoice, signature and practical business workflow tools."),
    makeItem("Email Signature Generator", "/tools/email-signature-generator", "email signature generator professional email signature html signature business signature outlook gmail", "fa-solid fa-signature", "Tool", "Business Tools", "Create professional email signatures with live preview and export options."),
    makeItem("Free Invoice Generator", "/tools/invoice-generator", "free invoice generator invoice maker billing invoice pdf client tax currency", "fa-solid fa-file-invoice-dollar", "Tool", "Business Tools", "Create professional invoices online with client details, tax, currency and PDF export.")
  ];

  const quickPickHrefs = [
    "/tools/real-estate",
    "/tools/finance",
    "/tools/job-tools",
    "/tools/pdf-tools",
    "/tools/social",
    "/tools/password-generator",
    "/tools/qr-code-generator",
    "/tools/image-compressor",
    "/tools/age-calculator-pro",
    "/tools/reorder-pdf-pages"
  ];

  const quickPicks = quickPickHrefs
    .map(function (href) {
      return allTools.find(function (item) { return item.href === href; });
    })
    .filter(Boolean);

  let activeIndex = -1;
  let currentResults = [];

  if (!suggestBox.id) {
    suggestBox.id = "searchSuggestList";
  }

  searchInput.setAttribute("role", "combobox");
  searchInput.setAttribute("aria-autocomplete", "list");
  searchInput.setAttribute("aria-expanded", "false");
  searchInput.setAttribute("aria-controls", suggestBox.id);
  suggestBox.setAttribute("role", "listbox");

  function scoreTool(item, q) {
    if (!q) return 0;

    const title = norm(item.title);
    const keywords = norm(item.keywords);
    const href = norm(item.href);
    const group = norm(item.group);
    const desc = norm(item.desc);

    let score = 0;

    if (title === q) score += 220;
    if (title.startsWith(q)) score += 150;
    if (title.includes(q)) score += 95;

    if (group === q) score += 100;
    if (group.startsWith(q)) score += 55;
    if (group.includes(q)) score += 35;

    if (href.includes(q)) score += 30;
    if (keywords.startsWith(q)) score += 60;
    if (keywords.includes(q)) score += 48;
    if (desc.includes(q)) score += 28;

    const qWords = q.split(/\s+/).filter(Boolean);
    qWords.forEach(function (word) {
      if (title.includes(word)) score += 18;
      if (group.includes(word)) score += 9;
      if (keywords.includes(word)) score += 8;
      if (desc.includes(word)) score += 5;
    });

    if (item.kind === "Category" && (title.includes(q) || group.includes(q))) {
      score += 18;
    }

    return score;
  }

  function filterCategoryCards(q) {
    const cards = document.querySelectorAll(".categories .card, .home-category-grid a, .home-category-card");
    cards.forEach(function (card) {
      const text = norm(card.innerText);
      card.style.display = !q || text.includes(q) ? "" : "none";
    });
  }

  function filterTrending(q) {
    const trendItems = document.querySelectorAll(".trending li, .home-trending-list li");
    trendItems.forEach(function (li) {
      const text = norm(li.innerText);
      li.style.display = !q || text.includes(q) ? "" : "none";
    });
  }

  function hideSuggestions() {
    suggestBox.style.display = "none";
    suggestBox.innerHTML = "";
    suggestBox.removeAttribute("data-floating");
    activeIndex = -1;
    currentResults = [];
    searchInput.setAttribute("aria-expanded", "false");
    searchInput.removeAttribute("aria-activedescendant");
  }

  function setActiveItem(index) {
    const items = suggestBox.querySelectorAll(".s-item");

    items.forEach(function (item, i) {
      const isActive = i === index;
      item.classList.toggle("active", isActive);
      item.setAttribute("aria-selected", isActive ? "true" : "false");
      item.style.background = isActive ? "linear-gradient(180deg,#f8fbff,#eef5ff)" : "";
      item.style.borderColor = isActive ? "#dbeafe" : "";
    });

    activeIndex = index;

    if (items[index]) {
      const activeId = items[index].id;
      if (activeId) {
        searchInput.setAttribute("aria-activedescendant", activeId);
      }
      items[index].scrollIntoView({ block: "nearest" });
    } else {
      searchInput.removeAttribute("aria-activedescendant");
    }
  }

  function goToHref(href) {
    if (href) window.location.href = href;
  }

  function syncSuggestPosition() {
    if (!suggestBox || suggestBox.style.display === "none") return;
    const rect = searchInput.getBoundingClientRect();
    const viewportWidth = window.innerWidth || document.documentElement.clientWidth || rect.width;
    const gap = viewportWidth <= 640 ? 8 : 12;
    const width = Math.min(rect.width, Math.max(220, viewportWidth - gap * 2));
    const left = Math.min(Math.max(gap, rect.left), Math.max(gap, viewportWidth - width - gap));
    suggestBox.dataset.floating = "true";
    suggestBox.style.setProperty("--sg-left", left + "px");
    suggestBox.style.setProperty("--sg-top", Math.max(gap, rect.bottom + 8) + "px");
    suggestBox.style.setProperty("--sg-width", width + "px");
  }

  function renderBadge(label, kind) {
    const bg = kind === "Category" ? "#eef2ff" : "#eff6ff";
    const border = kind === "Category" ? "#c7d2fe" : "#dbeafe";
    const color = kind === "Category" ? "#4338ca" : "#1d4ed8";

    return '<span style="display:inline-flex;align-items:center;gap:6px;padding:5px 9px;border-radius:999px;font-size:11px;font-weight:800;background:' + bg + ';border:1px solid ' + border + ';color:' + color + ';white-space:nowrap;">' + escapeHtml(label) + '</span>';
  }

  function renderSuggestions(results, metaLabel) {
    currentResults = results.slice();
    activeIndex = -1;

    if (!results.length) {
      hideSuggestions();
      return;
    }

    suggestBox.innerHTML = results.map(function (item, index) {
      const optionId = "search-option-" + index;
      const badges = [
        renderBadge(item.kind, item.kind),
        renderBadge(item.group, "group")
      ].join("");

      return (
        '<div class="s-item" id="' + optionId + '" role="option" aria-selected="false" data-index="' + index + '" data-href="' + escapeHtml(item.href) + '" style="align-items:flex-start;">' +
          '<div class="s-ico"><i class="' + escapeHtml(item.ico) + '"></i></div>' +
          '<div style="min-width:0;flex:1;">' +
            '<div class="s-text">' + escapeHtml(item.title) + '</div>' +
            '<div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:6px;">' + badges + '</div>' +
            '<div class="s-sub" style="margin-top:7px;line-height:1.5;word-break:normal;">' + escapeHtml(item.desc || item.href) + '</div>' +
            '<div class="s-sub" style="margin-top:4px;font-size:11px;opacity:.9;">' + escapeHtml(item.href) + '</div>' +
          '</div>' +
          '<div aria-hidden="true" style="margin-left:8px;color:#94a3b8;font-size:14px;font-weight:800;line-height:1.4;">↗</div>' +
        '</div>'
      );
    }).join("");

    suggestBox.style.display = "block";
    syncSuggestPosition();
    searchInput.setAttribute("aria-expanded", "true");
    suggestBox.setAttribute("data-mode", metaLabel || "results");

    const items = suggestBox.querySelectorAll(".s-item");
    items.forEach(function (item, index) {
      item.addEventListener("mouseenter", function () {
        setActiveItem(index);
      });

      item.addEventListener("mousedown", function (event) {
        event.preventDefault();
      });

      item.addEventListener("click", function () {
        goToHref(item.getAttribute("data-href"));
      });
    });
  }

  function showDefaultSuggestions() {
    renderSuggestions(quickPicks, "default");
  }

  function getInitialQuery() {
    try {
      const params = new URLSearchParams(window.location.search);
      return norm(params.get("q"));
    } catch (error) {
      return "";
    }
  }

  function updateSuggestions() {
    const q = norm(searchInput.value);

    filterCategoryCards(q);
    filterTrending(q);

    if (!q) {
      showDefaultSuggestions();
      return;
    }

    const ranked = allTools
      .map(function (item) {
        return Object.assign({}, item, { score: scoreTool(item, q) });
      })
      .filter(function (item) {
        return item.score > 0;
      })
      .sort(function (a, b) {
        if (b.score !== a.score) return b.score - a.score;
        if (a.kind !== b.kind) return a.kind === "Tool" ? -1 : 1;
        return a.title.localeCompare(b.title);
      })
      .slice(0, 8);

    if (!ranked.length) {
      suggestBox.innerHTML = "<div class=\"s-item\" style=\"cursor:default;align-items:flex-start;\"><div class=\"s-ico\"><i class=\"fa-solid fa-magnifying-glass\"></i></div><div style=\"min-width:0;flex:1;\"><div class=\"s-text\">No matching tool found</div><div class=\"s-sub\" style=\"margin-top:6px;line-height:1.5;word-break:normal;\">Try a broader keyword like PDF, finance, resume or calculator.</div></div></div>";
      suggestBox.style.display = "block";
      syncSuggestPosition();
      suggestBox.setAttribute("data-mode", "empty");
      searchInput.setAttribute("aria-expanded", "true");
      currentResults = [];
      activeIndex = -1;
      return;
    }

    renderSuggestions(ranked, "search");
  }

  searchInput.addEventListener("input", updateSuggestions);

  searchInput.addEventListener("focus", function () {
    if (norm(searchInput.value)) {
      updateSuggestions();
      return;
    }
    showDefaultSuggestions();
  });

  searchInput.addEventListener("keydown", function (event) {
    const items = suggestBox.querySelectorAll(".s-item");
    if (!items.length) return;

    if (event.key === "ArrowDown") {
      event.preventDefault();
      const nextIndex = activeIndex < items.length - 1 ? activeIndex + 1 : 0;
      setActiveItem(nextIndex);
      return;
    }

    if (event.key === "ArrowUp") {
      event.preventDefault();
      const nextIndex = activeIndex > 0 ? activeIndex - 1 : items.length - 1;
      setActiveItem(nextIndex);
      return;
    }

    if (event.key === "Enter") {
      if (activeIndex >= 0 && currentResults[activeIndex]) {
        event.preventDefault();
        goToHref(currentResults[activeIndex].href);
        return;
      }

      if (currentResults[0]) {
        event.preventDefault();
        goToHref(currentResults[0].href);
      }
      return;
    }

    if (event.key === "Escape") {
      hideSuggestions();
    }
  });



  window.addEventListener("resize", function () {
    if (suggestBox.style.display !== "none") syncSuggestPosition();
  });

  window.addEventListener("scroll", function () {
    if (suggestBox.style.display !== "none") syncSuggestPosition();
  }, { passive: true });

  document.addEventListener("click", function (event) {
    const clickedInside = suggestBox.contains(event.target) || searchInput.contains(event.target);
    if (!clickedInside) {
      hideSuggestions();
    }
  });
});