
(function() {
  if (window.__PRIME_TOOLS_UNIVERSAL_NAV__) return;
  window.__PRIME_TOOLS_UNIVERSAL_NAV__ = true;
  const data = {"toolsCategories": [{"slug": "ai-tools", "title": "AI Tools", "href": "/tools/ai-tools", "icon": "fa-solid fa-robot", "desc": "Live AI chat, writing, caption, SEO, FAQ, and future workflow helpers.", "tools": [{"title": "AI Caption Generator", "href": "/tools/ai-caption-generator"}, {"title": "AI SEO Title & Meta Generator", "href": "/tools/ai-seo-meta-generator"}, {"title": "AI FAQ Generator", "href": "/tools/ai-faq-generator"}, {"title": "AI Chat Assistant", "href": "/tools/ai-chat-assistant"}, {"title": "AI Cover Letter & Reply Helper", "href": "/tools/ai-cover-letter-reply-helper"}, {"title": "AI Study Notes Summarizer", "href": "/tools/ai-tools#ai-study-notes-summarizer"}, {"title": "AI Image Caption & Alt Text Tool", "href": "/tools/ai-tools#ai-image-alt-text-tool"}]}, {"slug": "business-tools", "title": "Business Tools", "href": "/tools/business-tools", "icon": "fa-solid fa-briefcase", "desc": "Invoices, GST, signatures, and business workflow helpers.", "tools": [{"title": "Email Signature Generator", "href": "/tools/email-signature-generator"}, {"title": "Free Invoice Generator", "href": "/tools/invoice-generator"}, {"title": "GST Invoice Generator (India) + PDF", "href": "/tools/gst-invoice-generator-india-pdf"}]}, {"slug": "real-estate", "title": "Real Estate Tools", "href": "/tools/real-estate", "icon": "fa-solid fa-house", "desc": "Land, cost, EMI, property, and buy-versus-rent planning tools.", "tools": [{"title": "Gaj to Square Feet Converter", "href": "/tools/gaj-to-sqft"}, {"title": "Bigha to Acre Converter", "href": "/tools/bigha-to-acre"}, {"title": "Square Meter to Square Feet Converter", "href": "/tools/sqm-to-sqft"}, {"title": "Plot Cost Calculator", "href": "/tools/plot-cost"}, {"title": "Plot Area Calculator (Length × Width)", "href": "/tools/plot-area-calculator"}, {"title": "Stamp Duty & Registration Calculator", "href": "/tools/stamp-duty-calculator"}, {"title": "Land Unit Mega Converter", "href": "/tools/land-unit-converter"}, {"title": "Circle Rate (Plot Value) Calculator", "href": "/tools/circle-rate-calculator"}, {"title": "Home Affordability Calculator", "href": "/tools/home-affordability-calculator"}, {"title": "Home Loan EMI Calculator", "href": "/tools/home-loan-emi"}, {"title": "Rent vs Buy Calculator", "href": "/tools/rent-vs-buy-calculator"}, {"title": "Global Rent vs Buy Calculator", "href": "/tools/usa-rent-vs-buy"}, {"title": "Home Sale Proceeds Calculator", "href": "/tools/home-sale-proceeds-calculator"}, {"title": "Closing Costs Calculator", "href": "/tools/closing-costs-calculator"}]}, {"slug": "finance", "title": "Finance Calculators", "href": "/tools/finance", "icon": "fa-solid fa-coins", "desc": "Savings, tax, percentage, discount, and money planning calculators.", "tools": [{"title": "Compound Interest Calculator", "href": "/tools/compound-interest"}, {"title": "SIP Calculator", "href": "/tools/sip-calculator"}, {"title": "Free Currency Converter", "href": "/tools/currency-converter"}, {"title": "Free Crypto Converter", "href": "/tools/crypto-converter"}, {"title": "FD Maturity Calculator", "href": "/tools/fd-calculator"}, {"title": "GST Calculator", "href": "/tools/gst-calculator"}, {"title": "Discount Calculator", "href": "/tools/discount-calculator"}, {"title": "Profit Margin Calculator", "href": "/tools/profit-margin"}, {"title": "Income Tax Calculator", "href": "/tools/income-tax-calculator"}, {"title": "FD vs SIP Comparison", "href": "/tools/fd-vs-sip"}, {"title": "Free Percentage Calculator", "href": "/tools/percentage-calculator"}, {"title": "Global Sales Tax Calculator", "href": "/tools/usa-sales-tax"}, {"title": "Global Tip Calculator", "href": "/tools/usa-tip-calculator"}]}, {"slug": "world-finance-mortgage", "title": "World Finance & Mortgage", "href": "/tools/world-finance-mortgage", "icon": "fa-solid fa-globe", "desc": "Mortgage, lease, paycheck, sales tax, and global finance tools.", "tools": [{"title": "Global Amortization Schedule Tool", "href": "/tools/usa-amortization"}, {"title": "Global Lease Calculator", "href": "/tools/usa-lease-calculator"}, {"title": "U.S. Mortgage Calculator", "href": "/tools/usa-mortgage-calculator"}, {"title": "Global Paycheck Calculator", "href": "/tools/usa-paycheck-calculator"}]}, {"slug": "personal-health", "title": "Personal & Health", "href": "/tools/personal-health", "icon": "fa-solid fa-heart-pulse", "desc": "Age, BMI, calorie, water, weight, and daily health calculators.", "tools": [{"title": "Age Calculator (Exact)", "href": "/tools/age-calculator-pro"}, {"title": "Anniversary Calculator", "href": "/tools/anniversary-calculator"}, {"title": "Calorie Calculator", "href": "/tools/calorie-calculator"}, {"title": "BMI + BMR Calculator", "href": "/tools/bmi-bmr-calculator"}, {"title": "Water Intake Calculator", "href": "/tools/water-intake-calculator"}, {"title": "Body Fat Calculator", "href": "/tools/body-fat-calculator"}, {"title": "TDEE Calculator", "href": "/tools/tdee-calculator"}, {"title": "Ideal Weight Calculator", "href": "/tools/ideal-weight-calculator"}, {"title": "Macro Calculator", "href": "/tools/macro-calculator"}]}, {"slug": "job-tools", "title": "Job & Career Tools", "href": "/tools/job-tools", "icon": "fa-solid fa-file-lines", "desc": "Resume, cover letter, and work-focused writing tools.", "tools": [{"title": "Free India Resume Builder with QR Code", "href": "/tools/india-resume-builder-qr"}, {"title": "USA Resume Builder + QR", "href": "/tools/usa-resume-builder"}, {"title": "Cover Letter Builder + QR PDF", "href": "/tools/cover-letter-builder-pdf"}, {"title": "Word Counter and Text Analysis Tool", "href": "/tools/word-counter"}]}, {"slug": "pdf-tools", "title": "PDF Tools", "href": "/tools/pdf-tools", "icon": "fa-solid fa-file-pdf", "desc": "Convert, merge, split, reorder, rotate, and secure PDF workflows.", "tools": [{"title": "PDF to DOCX, DOC, PPTX & XLSX Converter", "href": "/tools/pdf-to-office-converter"}, {"title": "PDF to JSON, Watermark & Metadata Editor", "href": "/tools/pdf-json-watermark-metadata"}, {"title": "Image to PDF Converter", "href": "/tools/image-to-pdf"}, {"title": "Text to PDF Converter", "href": "/tools/text-to-pdf"}, {"title": "PDF to JPG Converter", "href": "/tools/pdf-to-jpg"}, {"title": "Merge PDF Tool", "href": "/tools/merge-pdf"}, {"title": "Split PDF Tool", "href": "/tools/split-pdf"}, {"title": "PDF to PNG Converter", "href": "/tools/pdf-to-png"}, {"title": "Rotate PDF Tool", "href": "/tools/rotate-pdf"}, {"title": "Reorder PDF Pages Tool", "href": "/tools/reorder-pdf-pages"}, {"title": "Extract PDF Pages Tool", "href": "/tools/extract-pdf-pages"}]}, {"slug": "image-utility", "title": "Image & Utility", "href": "/tools/image-utility", "icon": "fa-solid fa-image", "desc": "Image helpers, QR, barcode, masking, favicon, and utility tools.", "tools": [{"title": "Aadhaar / PAN Mask Blur Tool", "href": "/tools/aadhaar-pan-mask"}, {"title": "Barcode Generator Tool", "href": "/tools/barcode-generator"}, {"title": "Color Picker Image", "href": "/tools/color-picker-image"}, {"title": "Free Favicon Generator", "href": "/tools/favicon-generator"}, {"title": "Image Compressor Tool", "href": "/tools/image-compressor"}, {"title": "Image Resizer + Cropper Tool", "href": "/tools/image-resizer-cropper"}, {"title": "JPG ↔ PNG Converter Tool", "href": "/tools/jpg-png-converter"}, {"title": "Password Generator Tool", "href": "/tools/password-generator"}, {"title": "QR Code Generator Tool", "href": "/tools/qr-code-generator"}, {"title": "Background Remover Tool", "href": "/tools/usa-background-remover"}]}, {"slug": "social", "title": "Social Media Tools", "href": "/tools/social", "icon": "fa-solid fa-hashtag", "desc": "Captions, bios, hashtags, usernames, and social writing helpers.", "tools": [{"title": "Bio Line Generator Tool", "href": "/tools/bio-line-generator"}, {"title": "Emoji Combos Generator Tool", "href": "/tools/emoji-combos"}, {"title": "Fancy Text Generator Tool", "href": "/tools/fancy-text"}, {"title": "Hashtag Generator Tool", "href": "/tools/hashtag-generator"}, {"title": "Instagram Caption Generator Tool", "href": "/tools/instagram-caption-generator"}, {"title": "LinkedIn Headline Generator Tool", "href": "/tools/linkedin-headline-generator"}, {"title": "Stylish Name Generator Tool", "href": "/tools/stylish-name"}, {"title": "Username Generator Tool", "href": "/tools/username-generator"}, {"title": "YouTube Title Generator Tool", "href": "/tools/youtube-title-generator"}]}, {"slug": "student-academic", "title": "Student & Academic", "href": "/tools/student-academic", "icon": "fa-solid fa-graduation-cap", "desc": "Study planning and GPA helpers for students.", "tools": [{"title": "Study Planner + Revision", "href": "/tools/study-planner-india"}, {"title": "Global GPA Calculator", "href": "/tools/usa-gpa-calculator"}]}, {"slug": "travel-visa-tools", "title": "Travel & Visa Tools", "href": "/tools/travel-visa-tools", "icon": "fa-solid fa-plane", "desc": "Travel planning, visa photo, time zone, and trip checklist tools.", "tools": [{"title": "Passport / Visa Photo Maker", "href": "/tools/passport-visa-photo-maker"}, {"title": "Time Zone Meeting Planner", "href": "/tools/time-zone-meeting-planner"}, {"title": "Flight Price Tracker / Fare Alert Planner", "href": "/tools/flight-price-tracker"}, {"title": "Travel Budget Calculator", "href": "/tools/travel-budget-calculator"}, {"title": "Packing List Generator", "href": "/tools/packing-list-generator"}, {"title": "Flight Battery Rule Checker", "href": "/tools/power-bank-flight-rule-checker"}, {"title": "Event Time Announcer", "href": "/tools/event-time-announcer"}]}, {"slug": "fun-tools", "title": "Fun Tools", "href": "/tools/fun-tools", "icon": "fa-solid fa-gamepad", "desc": "Pickers, games, timers, randomizers, and light interactive tools.", "tools": [{"title": "CPS Test", "href": "/tools/cps-test"}, {"title": "Funny Name Generator", "href": "/tools/funny-name-generator"}, {"title": "Gamer Name Generator", "href": "/tools/gamer-name-generator"}, {"title": "Giveaway Winner Picker", "href": "/tools/giveaway-winner-picker"}, {"title": "Movie Picker Wheel", "href": "/tools/movie-picker-wheel"}, {"title": "Random Name Picker", "href": "/tools/random-name-picker"}, {"title": "Reaction Time Test", "href": "/tools/reaction-time-test"}, {"title": "Secret Santa Generator", "href": "/tools/secret-santa-generator"}, {"title": "Spin Wheel", "href": "/tools/spin-wheel"}, {"title": "Stopwatch & Timer", "href": "/tools/stopwatch-timer"}, {"title": "What Should I Watch Tool", "href": "/tools/what-should-i-watch"}]}], "guideCategories": [{"slug": "ai-tools", "title": "AI Tools Guide", "href": "/guides/ai-tools", "icon": "fa-solid fa-robot", "desc": "Open category guide and setup notes.", "guides": [{"title": "How to Use AI Chat Assistant", "href": "/guides/ai-chat-assistant-guide"}, {"title": "How to Use AI Cover Letter & Reply Helper", "href": "/guides/ai-cover-letter-reply-helper-guide"}, {"title": "How to Use AI Caption Generator", "href": "/guides/ai-caption-generator-guide"}, {"title": "How to Use AI SEO Title & Meta Generator", "href": "/guides/ai-seo-meta-generator-guide"}, {"title": "How to Use AI FAQ Generator", "href": "/guides/ai-faq-generator-guide"}]}, {"slug": "business-tools", "title": "Business Tools Guide", "href": "/guides/business-tools", "icon": "fa-solid fa-briefcase", "desc": "Open category guide and related pages.", "guides": [{"title": "How to Use Email Signature Generator", "href": "/guides/email-signature-generator-guide"}, {"title": "How to Use Free Invoice Generator", "href": "/guides/invoice-generator-guide"}, {"title": "How to Use GST Invoice Generator (India) + PDF", "href": "/guides/gst-invoice-generator-india-pdf-guide"}]}, {"slug": "real-estate", "title": "Real Estate Tools Guide", "href": "/guides/real-estate", "icon": "fa-solid fa-house", "desc": "Open category guide and related pages.", "guides": [{"title": "How to Use Gaj to Square Feet Converter", "href": "/guides/gaj-to-sqft-guide"}, {"title": "How to Use Bigha to Acre Converter", "href": "/guides/bigha-to-acre-guide"}, {"title": "How to Use Square Meter to Square Feet Converter", "href": "/guides/sqm-to-sqft-guide"}, {"title": "How to Use Plot Cost Calculator", "href": "/guides/plot-cost-guide"}, {"title": "How to Use Plot Area Calculator (Length × Width)", "href": "/guides/plot-area-calculator-guide"}, {"title": "How to Use Stamp Duty & Registration Calculator", "href": "/guides/stamp-duty-calculator-guide"}, {"title": "How to Use Land Unit Mega Converter", "href": "/guides/land-unit-converter-guide"}, {"title": "How to Use Circle Rate (Plot Value) Calculator", "href": "/guides/circle-rate-calculator-guide"}, {"title": "How to Use Home Affordability Calculator", "href": "/guides/home-affordability-calculator-guide"}, {"title": "How to Use Home Loan EMI Calculator", "href": "/guides/home-loan-emi-guide"}, {"title": "How to Use Rent vs Buy Calculator", "href": "/guides/rent-vs-buy-calculator-guide"}, {"title": "How to Use Global Rent vs Buy Calculator", "href": "/guides/usa-rent-vs-buy-guide"}, {"title": "How to Use Home Sale Proceeds Calculator", "href": "/guides/home-sale-proceeds-calculator-guide"}, {"title": "How to Use Closing Costs Calculator", "href": "/guides/closing-costs-calculator-guide"}]}, {"slug": "finance", "title": "Finance Calculators Guide", "href": "/guides/finance", "icon": "fa-solid fa-coins", "desc": "Open category guide and related pages.", "guides": [{"title": "How to Use Compound Interest Calculator", "href": "/guides/compound-interest-guide"}, {"title": "How to Use SIP Calculator", "href": "/guides/sip-calculator-guide"}, {"title": "How to Use Free Currency Converter", "href": "/guides/currency-converter-guide"}, {"title": "How to Use Free Crypto Converter", "href": "/guides/crypto-converter-guide"}, {"title": "How to Use FD Maturity Calculator", "href": "/guides/fd-calculator-guide"}, {"title": "How to Use GST Calculator", "href": "/guides/gst-calculator-guide"}, {"title": "How to Use Discount Calculator", "href": "/guides/discount-calculator-guide"}, {"title": "How to Use Profit Margin Calculator", "href": "/guides/profit-margin-guide"}, {"title": "How to Use Income Tax Calculator", "href": "/guides/income-tax-calculator-guide"}, {"title": "How to Use FD vs SIP Comparison", "href": "/guides/fd-vs-sip-guide"}, {"title": "How to Use Free Percentage Calculator", "href": "/guides/percentage-calculator-guide"}, {"title": "How to Use Global Sales Tax Calculator", "href": "/guides/usa-sales-tax-guide"}, {"title": "How to Use Global Tip Calculator", "href": "/guides/usa-tip-calculator-guide"}]}, {"slug": "world-finance-mortgage", "title": "World Finance & Mortgage Guide", "href": "/guides/world-finance-mortgage", "icon": "fa-solid fa-globe", "desc": "Open category guide and related pages.", "guides": [{"title": "How to Use Global Amortization Schedule Tool", "href": "/guides/usa-amortization-guide"}, {"title": "How to Use Global Lease Calculator", "href": "/guides/usa-lease-calculator-guide"}, {"title": "How to Use U.S. Mortgage Calculator", "href": "/guides/usa-mortgage-calculator-guide"}, {"title": "How to Use Global Paycheck Calculator", "href": "/guides/usa-paycheck-calculator-guide"}]}, {"slug": "personal-health", "title": "Personal & Health Guide", "href": "/guides/personal-health", "icon": "fa-solid fa-heart-pulse", "desc": "Open category guide and related pages.", "guides": [{"title": "How to Use Age Calculator (Exact)", "href": "/guides/age-calculator-pro-guide"}, {"title": "How to Use Anniversary Calculator", "href": "/guides/anniversary-calculator-guide"}, {"title": "How to Use Calorie Calculator", "href": "/guides/calorie-calculator-guide"}, {"title": "How to Use BMI + BMR Calculator", "href": "/guides/bmi-bmr-calculator-guide"}, {"title": "How to Use Water Intake Calculator", "href": "/guides/water-intake-calculator-guide"}, {"title": "How to Use Body Fat Calculator", "href": "/guides/body-fat-calculator-guide"}, {"title": "How to Use TDEE Calculator", "href": "/guides/tdee-calculator-guide"}, {"title": "How to Use Ideal Weight Calculator", "href": "/guides/ideal-weight-calculator-guide"}, {"title": "How to Use Macro Calculator", "href": "/guides/macro-calculator-guide"}]}, {"slug": "job-tools", "title": "Job & Career Tools Guide", "href": "/guides/job-tools", "icon": "fa-solid fa-file-lines", "desc": "Open category guide and related pages.", "guides": [{"title": "How to Use Free India Resume Builder with QR Code", "href": "/guides/india-resume-builder-qr-guide"}, {"title": "How to Use USA Resume Builder + QR", "href": "/guides/usa-resume-builder-guide"}, {"title": "How to Use Cover Letter Builder + QR PDF", "href": "/guides/cover-letter-builder-pdf-guide"}, {"title": "How to Use Word Counter and Text Analysis Tool", "href": "/guides/word-counter-guide"}]}, {"slug": "pdf-tools", "title": "PDF Tools Guide", "href": "/guides/pdf-tools", "icon": "fa-solid fa-file-pdf", "desc": "Open category guide and related pages.", "guides": [{"title": "How to Use PDF to Office Converter", "href": "/guides/pdf-to-office-converter-guide"}, {"title": "How to Use PDF to JSON, Watermark & Metadata Editor", "href": "/guides/pdf-json-watermark-metadata-guide"}, {"title": "How to Use Image to PDF Converter", "href": "/guides/image-to-pdf-guide"}, {"title": "How to Use Text to PDF Converter", "href": "/guides/text-to-pdf-guide"}, {"title": "How to Use PDF to JPG Converter", "href": "/guides/pdf-to-jpg-guide"}, {"title": "How to Use Merge PDF Tool", "href": "/guides/merge-pdf-guide"}, {"title": "How to Use Split PDF Tool", "href": "/guides/split-pdf-guide"}, {"title": "How to Use PDF to PNG Converter", "href": "/guides/pdf-to-png-guide"}, {"title": "How to Use Rotate PDF Tool", "href": "/guides/rotate-pdf-guide"}, {"title": "How to Use Reorder PDF Pages Tool", "href": "/guides/reorder-pdf-pages-guide"}, {"title": "How to Use Extract PDF Pages Tool", "href": "/guides/extract-pdf-pages-guide"}]}, {"slug": "image-utility", "title": "Image & Utility Guide", "href": "/guides/image-utility", "icon": "fa-solid fa-image", "desc": "Open category guide and related pages.", "guides": [{"title": "How to Use Aadhaar / PAN Mask Blur Tool", "href": "/guides/aadhaar-pan-mask-guide"}, {"title": "How to Use Barcode Generator Tool", "href": "/guides/barcode-generator-guide"}, {"title": "How to Use Color Picker Image", "href": "/guides/color-picker-image-guide"}, {"title": "How to Use Free Favicon Generator", "href": "/guides/favicon-generator-guide"}, {"title": "How to Use Image Compressor Tool", "href": "/guides/image-compressor-guide"}, {"title": "How to Use Image Resizer + Cropper Tool", "href": "/guides/image-resizer-cropper-guide"}, {"title": "How to Use JPG ↔ PNG Converter Tool", "href": "/guides/jpg-png-converter-guide"}, {"title": "How to Use Password Generator Tool", "href": "/guides/password-generator-guide"}, {"title": "How to Use QR Code Generator Tool", "href": "/guides/qr-code-generator-guide"}, {"title": "How to Use Background Remover Tool", "href": "/guides/usa-background-remover-guide"}]}, {"slug": "social", "title": "Social Media Tools Guide", "href": "/guides/social", "icon": "fa-solid fa-hashtag", "desc": "Open category guide and related pages.", "guides": [{"title": "How to Use Bio Line Generator Tool", "href": "/guides/bio-line-generator-guide"}, {"title": "How to Use Emoji Combos Generator Tool", "href": "/guides/emoji-combos-guide"}, {"title": "How to Use Fancy Text Generator Tool", "href": "/guides/fancy-text-guide"}, {"title": "How to Use Hashtag Generator Tool", "href": "/guides/hashtag-generator-guide"}, {"title": "How to Use Instagram Caption Generator Tool", "href": "/guides/instagram-caption-generator-guide"}, {"title": "How to Use LinkedIn Headline Generator Tool", "href": "/guides/linkedin-headline-generator-guide"}, {"title": "How to Use Stylish Name Generator Tool", "href": "/guides/stylish-name-guide"}, {"title": "How to Use Username Generator Tool", "href": "/guides/username-generator-guide"}, {"title": "How to Use YouTube Title Generator Tool", "href": "/guides/youtube-title-generator-guide"}]}, {"slug": "student-academic", "title": "Student & Academic Guide", "href": "/guides/student-academic", "icon": "fa-solid fa-graduation-cap", "desc": "Open category guide and related pages.", "guides": [{"title": "How to Use Study Planner + Revision", "href": "/guides/study-planner-india-guide"}, {"title": "How to Use Global GPA Calculator", "href": "/guides/usa-gpa-calculator-guide"}]}, {"slug": "travel-visa-tools", "title": "Travel & Visa Tools Guide", "href": "/guides/travel-visa-tools", "icon": "fa-solid fa-plane", "desc": "Open category guide and related pages.", "guides": [{"title": "How to Use Passport / Visa Photo Maker", "href": "/guides/passport-visa-photo-maker-guide"}, {"title": "How to Use Time Zone Meeting Planner", "href": "/guides/time-zone-meeting-planner-guide"}, {"title": "How to Use Flight Price Tracker / Fare Alert Planner", "href": "/guides/flight-price-tracker-guide"}, {"title": "How to Use Travel Budget Calculator", "href": "/guides/travel-budget-calculator-guide"}, {"title": "How to Use Packing List Generator", "href": "/guides/packing-list-generator-guide"}, {"title": "How to Use Flight Battery Rule Checker", "href": "/guides/power-bank-flight-rule-checker-guide"}, {"title": "How to Use Event Time Announcer", "href": "/guides/event-time-announcer-guide"}]}, {"slug": "fun-tools", "title": "Fun Tools Guide", "href": "/guides/fun-tools", "icon": "fa-solid fa-gamepad", "desc": "Open category guide and related pages.", "guides": [{"title": "How to Use CPS Test", "href": "/guides/cps-test-guide"}, {"title": "How to Use Funny Name Generator", "href": "/guides/funny-name-generator-guide"}, {"title": "How to Use Gamer Name Generator", "href": "/guides/gamer-name-generator-guide"}, {"title": "How to Use Giveaway Winner Picker", "href": "/guides/giveaway-winner-picker-guide"}, {"title": "How to Use Movie Picker Wheel", "href": "/guides/movie-picker-wheel-guide"}, {"title": "How to Use Random Name Picker", "href": "/guides/random-name-picker-guide"}, {"title": "How to Use Reaction Time Test", "href": "/guides/reaction-time-test-guide"}, {"title": "How to Use Secret Santa Generator", "href": "/guides/secret-santa-generator-guide"}, {"title": "How to Use Spin Wheel", "href": "/guides/spin-wheel-guide"}, {"title": "How to Use Stopwatch & Timer", "href": "/guides/stopwatch-timer-guide"}, {"title": "How to Use What Should I Watch Tool", "href": "/guides/what-should-i-watch-guide"}]}], "mainPages": [{"title": "All Guides", "href": "/guides", "icon": "fa-solid fa-book-open"}, {"title": "About Us", "href": "/pages/about", "icon": "fa-solid fa-circle-info"}, {"title": "Contact Us", "href": "/pages/contact", "icon": "fa-solid fa-envelope"}, {"title": "Privacy Policy", "href": "/pages/privacy-policy", "icon": "fa-solid fa-shield-halved"}, {"title": "Disclaimer", "href": "/pages/disclaimer", "icon": "fa-solid fa-triangle-exclamation"}, {"title": "Terms & Conditions", "href": "/pages/terms", "icon": "fa-solid fa-file-contract"}]};
  const doc = document;

  function makeLink(href, text, cls, icon) {
    const a = doc.createElement('a');
    a.href = href;
    a.className = cls || '';
    a.innerHTML = (icon ? '<span><i class="' + icon + '"></i> ' + text + '</span>' : '<span>' + text + '</span>') + '<small><i class="fa-solid fa-arrow-right"></i></small>';
    return a;
  }

  function currentPath() {
    const p = window.location.pathname || '/';
    return p.endsWith('/') && p !== '/' ? p.slice(0, -1) : p;
  }

  function markCurrentLinks(root) {
    const here = currentPath();
    root.querySelectorAll('a[href]').forEach(function(a) {
      const href = a.getAttribute('href');
      if (!href || href.startsWith('mailto:')) return;
      const norm = href.endsWith('/') && href !== '/' ? href.slice(0, -1) : href;
      if (norm === here) {
        a.style.borderColor = '#bfdbfe';
        a.style.background = 'linear-gradient(180deg,#eff6ff,#eef2ff)';
        a.style.color = '#1d4ed8';
      }
    });
  }

  function buildAccordionItem(item, type) {
    const wrap = doc.createElement('div');
    wrap.className = 'uth-acc-item';
    const btn = doc.createElement('button');
    btn.type = 'button';
    btn.className = 'uth-acc-btn';
    btn.innerHTML = '<span class="uth-acc-left"><span class="uth-acc-icon"><i class="' + (item.icon || 'fa-solid fa-folder') + '"></i></span><span class="uth-acc-text">' + item.title + '<span>' + (item.desc || '') + '</span></span></span><span class="uth-acc-caret"><i class="fa-solid fa-chevron-down"></i></span>';
    const panel = doc.createElement('div');
    panel.className = 'uth-acc-panel';
    panel.appendChild(makeLink(item.href, 'Open ' + item.title, 'uth-parent-link'));
    const list = doc.createElement('div');
    list.className = 'uth-link-list';
    const items = type === 'tools' ? (item.tools || []) : (item.guides || []);
    if (!items.length) {
      const empty = doc.createElement('div');
      empty.className = 'uth-empty';
      empty.textContent = 'No links found here yet.';
      list.appendChild(empty);
    } else {
      items.forEach(function(child) {
        list.appendChild(makeLink(child.href, child.title, 'uth-link-item'));
      });
    }
    panel.appendChild(list);
    btn.addEventListener('click', function() { wrap.classList.toggle('is-open'); });
    wrap.appendChild(btn);
    wrap.appendChild(panel);
    return wrap;
  }

  function filterNav(term, drawer) {
    const q = (term || '').trim().toLowerCase();
    drawer.querySelectorAll('.uth-link-item, .uth-parent-link, .uth-simple-link, .uth-home-link').forEach(function(el) {
      const text = (el.textContent || '').toLowerCase();
      el.style.display = !q || text.includes(q) ? '' : 'none';
    });
    drawer.querySelectorAll('.uth-acc-item').forEach(function(item) {
      const visibleChildren = Array.from(item.querySelectorAll('.uth-link-item, .uth-parent-link')).some(function(el) { return el.style.display !== 'none'; });
      item.style.display = !q || visibleChildren || (item.textContent || '').toLowerCase().includes(q) ? '' : 'none';
      if (q && visibleChildren) item.classList.add('is-open');
    });
  }

  function ensureSkipLink(body) {
    if (doc.querySelector('.uth-skip-link')) return;
    const skip = doc.createElement('a');
    skip.className = 'uth-skip-link';
    skip.href = '#main-content';
    skip.textContent = 'Skip to main content';
    body.insertBefore(skip, body.firstChild);
  }

  function getFocusable(root) {
    return Array.from(root.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'))
      .filter(function(el) { return el.offsetParent !== null || el === doc.activeElement; });
  }

  function inject() {
    const body = doc.body;
    if (!body) return;
    ensureSkipLink(body);
    body.classList.add('uth-menu-present');
    const btn = doc.createElement('button');
    btn.type = 'button';
    btn.className = 'uth-menu-btn';
    btn.setAttribute('aria-label', 'Open site menu');
    btn.innerHTML = '<i class="fa-solid fa-bars"></i>';
    const backdrop = doc.createElement('div');
    backdrop.className = 'uth-backdrop';
    const drawer = doc.createElement('aside');
    drawer.className = 'uth-drawer';
    drawer.id = 'uth-site-drawer';
    drawer.setAttribute('aria-label', 'Site navigation');
    drawer.setAttribute('tabindex', '-1');
    drawer.setAttribute('aria-hidden', 'true');
    drawer.innerHTML = '<div class="uth-drawer-header"><div class="uth-drawer-top"><div class="uth-brand"><strong>Prime Tools Hub</strong><span>Browse tools, guides, and main pages from one universal menu.</span></div><button type="button" class="uth-close-btn" aria-label="Close menu"><i class="fa-solid fa-xmark"></i></button></div></div><div class="uth-drawer-body"></div>';
    const bodyWrap = drawer.querySelector('.uth-drawer-body');
    bodyWrap.appendChild(makeLink('/', 'Home', 'uth-home-link', 'fa-solid fa-house'));
    const menuSearch = doc.createElement('label');
    menuSearch.className = 'uth-drawer-search';
    menuSearch.innerHTML = '<i class="fa-solid fa-magnifying-glass"></i><input type="search" placeholder="Search tools, guides, and pages..." aria-label="Search menu items">';
    bodyWrap.appendChild(menuSearch);

    const toolSection = doc.createElement('section');
    toolSection.className = 'uth-nav-section';
    toolSection.innerHTML = '<div class="uth-nav-section-title"><i class="fa-solid fa-screwdriver-wrench"></i><span>Tools Category</span></div><div class="uth-accordion"></div>';
    const toolAcc = toolSection.querySelector('.uth-accordion');
    data.toolsCategories.forEach(function(item) { toolAcc.appendChild(buildAccordionItem(item, 'tools')); });
    bodyWrap.appendChild(toolSection);

    const guideSection = doc.createElement('section');
    guideSection.className = 'uth-nav-section';
    guideSection.innerHTML = '<div class="uth-nav-section-title"><i class="fa-solid fa-book-open"></i><span>Guide Category</span></div><div class="uth-simple-links" style="margin-bottom:8px"></div><div class="uth-accordion"></div>';
    guideSection.querySelector('.uth-simple-links').appendChild(makeLink('/guides', 'All Guides', 'uth-simple-link'));
    const guideAcc = guideSection.querySelector('.uth-accordion');
    data.guideCategories.forEach(function(item) { guideAcc.appendChild(buildAccordionItem(item, 'guides')); });
    bodyWrap.appendChild(guideSection);

    const pageSection = doc.createElement('section');
    pageSection.className = 'uth-nav-section';
    pageSection.innerHTML = '<div class="uth-nav-section-title"><i class="fa-solid fa-circle-info"></i><span>Main Pages</span></div><div class="uth-simple-links"></div>';
    const pageLinks = pageSection.querySelector('.uth-simple-links');
    data.mainPages.forEach(function(item) { if (item.href !== '/guides') pageLinks.appendChild(makeLink(item.href, item.title, 'uth-simple-link', item.icon)); });
    bodyWrap.appendChild(pageSection);

    body.appendChild(btn); body.appendChild(backdrop); body.appendChild(drawer); markCurrentLinks(drawer);
    btn.setAttribute('aria-expanded', 'false');
    btn.setAttribute('aria-controls', 'uth-site-drawer');
    let lastFocused = null;
    function openNav() {
      lastFocused = doc.activeElement;
      body.classList.add('uth-nav-open');
      btn.setAttribute('aria-expanded', 'true');
      drawer.setAttribute('aria-hidden', 'false');
      setTimeout(function(){ searchInput.focus(); }, 60);
    }
    function closeNav() {
      body.classList.remove('uth-nav-open');
      btn.setAttribute('aria-expanded', 'false');
      drawer.setAttribute('aria-hidden', 'true');
      if (lastFocused && typeof lastFocused.focus === 'function') lastFocused.focus();
    }
    btn.addEventListener('click', openNav); backdrop.addEventListener('click', closeNav); drawer.querySelector('.uth-close-btn').addEventListener('click', closeNav);
    doc.addEventListener('keydown', function(ev) {
      if (ev.key === 'Escape') closeNav();
      if (ev.key === 'Tab' && body.classList.contains('uth-nav-open')) {
        const focusable = getFocusable(drawer);
        if (!focusable.length) return;
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (ev.shiftKey && doc.activeElement === first) { ev.preventDefault(); last.focus(); }
        else if (!ev.shiftKey && doc.activeElement === last) { ev.preventDefault(); first.focus(); }
      }
    });
    const searchInput = drawer.querySelector('input[type="search"]');
    searchInput.addEventListener('input', function() { filterNav(searchInput.value, drawer); });
  }
  if (doc.readyState === 'loading') { doc.addEventListener('DOMContentLoaded', inject); } else { inject(); }
})();
