(function(){
  const $ = (id) => document.getElementById(id);
  const els = {
    topic: $('topic'), platform: $('platform'), tone: $('tone'), language: $('language'), goal: $('goal'), audience: $('audience'), keywords: $('keywords'), cta: $('cta'), emojiLevel: $('emojiLevel'),
    generateBtn: $('generateBtn'), resetBtn: $('resetBtn'), statusBox: $('statusBox'), emptyState: $('emptyState'), resultPanel: $('resultPanel'),
    hookOutput: $('hookOutput'), primaryOutput: $('primaryOutput'), shortOutput: $('shortOutput'), ctaOutput: $('ctaOutput'), hashtagsOutput: $('hashtagsOutput'), noteOutput: $('noteOutput'),
    hookCount: $('hookCount'), primaryCount: $('primaryCount'), shortCount: $('shortCount'), copyAllBtn: $('copyAllBtn')
  };
  function setStatus(type, message){ els.statusBox.className = 'status-box show ' + type; els.statusBox.textContent = message; }
  function clearStatus(){ els.statusBox.className = 'status-box info'; els.statusBox.textContent = ''; els.statusBox.classList.remove('show'); }
  function setText(el, text){ el.textContent = text || ''; }
  function countText(value){ return String(value || '').trim().length; }
  async function copyText(value, label){ if(!value) return; await navigator.clipboard.writeText(value); setStatus('success', label + ' copied.'); }
  document.querySelectorAll('[data-copy-target]').forEach((btn)=>{ btn.addEventListener('click', async ()=>{ const target = $(btn.getAttribute('data-copy-target')); await copyText(target?.textContent || '', btn.textContent.trim()); }); });
  els.copyAllBtn.addEventListener('click', async ()=>{ const hashtags = Array.from(els.hashtagsOutput.querySelectorAll('.chip')).map((el)=>el.textContent).join(' '); const full = [els.hookOutput.textContent, '', els.primaryOutput.textContent, '', els.shortOutput.textContent, '', els.ctaOutput.textContent, hashtags].filter(Boolean).join('\n'); await copyText(full, 'Full caption output'); });
  els.resetBtn.addEventListener('click', ()=>{ document.querySelectorAll('textarea, input').forEach((el)=> el.value=''); document.querySelectorAll('select').forEach((el)=>{ if(el.options.length) el.selectedIndex = 0; }); els.platform.value='Instagram'; els.tone.value='Friendly'; els.language.value='English'; els.goal.value='Engagement'; els.emojiLevel.value='Medium'; els.emptyState.hidden = false; els.resultPanel.hidden = true; clearStatus(); });
  els.generateBtn.addEventListener('click', async ()=>{
    clearStatus();
    const payload = { topic: els.topic.value, platform: els.platform.value, tone: els.tone.value, language: els.language.value, goal: els.goal.value, audience: els.audience.value, keywords: els.keywords.value, cta: els.cta.value, emojiLevel: els.emojiLevel.value };
    if(String(payload.topic || '').trim().length < 8){ setStatus('error', 'Please describe the post idea in a little more detail.'); els.topic.focus(); return; }
    els.generateBtn.disabled = true; els.generateBtn.textContent = 'Generating...'; setStatus('info', 'Generating caption ideas...');
    try {
      const res = await fetch('/api/ai-caption', { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(payload) });
      const data = await res.json().catch(()=> null);
      if(!res.ok || !data){ throw new Error(data?.message || 'Caption generation failed.'); }
      els.emptyState.hidden = true; els.resultPanel.hidden = false;
      setText(els.hookOutput, data.hook || ''); setText(els.primaryOutput, data.primary_caption || ''); setText(els.shortOutput, data.short_caption || ''); setText(els.ctaOutput, data.cta_line || ''); setText(els.noteOutput, data.posting_note || '');
      els.hookCount.textContent = countText(data.hook) + ' chars'; els.primaryCount.textContent = countText(data.primary_caption) + ' chars'; els.shortCount.textContent = countText(data.short_caption) + ' chars';
      els.hashtagsOutput.innerHTML = '';
      (Array.isArray(data.hashtags) ? data.hashtags : []).forEach((tag)=>{ const span = document.createElement('span'); span.className='chip'; span.textContent = tag; els.hashtagsOutput.appendChild(span); });
      const used = res.headers.get('x-pt-count'); const limit = res.headers.get('x-pt-limit');
      setStatus('success', used && limit ? `Caption ready. Daily usage: ${used}/${limit}.` : 'Caption ready.');
    } catch (error) {
      setStatus('error', error instanceof Error ? error.message : 'Caption generation failed.');
    } finally {
      els.generateBtn.disabled = false; els.generateBtn.innerHTML = '<i class="fa-solid fa-bolt"></i> Generate Caption';
    }
  });
})();